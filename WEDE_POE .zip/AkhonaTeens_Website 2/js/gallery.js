// =====================================================================
// gallery.js: photo gallery with category filter + lightbox.
//
//   * Without JavaScript each thumbnail is a normal link to the large photo.
//   * With JavaScript, clicking opens a lightbox built on a native <dialog>
//     (focus is trapped, Escape closes, focus returns to the thumbnail).
//   * Lightbox controls: previous / next buttons, ← → keys, swipe on touch
//     screens, click the photo to zoom, click the dark area to close.
//   * Only photos in the current filter are part of the lightbox sequence.
// =====================================================================
(function () {
    "use strict";

    var utils = window.ATLF.utils, el = utils.el, $ = utils.$, $$ = utils.$$;
    var grid = $("#gallery-grid");
    if (!grid) { return; }

    var figures = $$(".gallery-item", grid);
    var chips = $$(".chip[data-filter]");
    var countEl = $("#gallery-count");

    // ---------------------------------------------------------------
    // Filtering
    // ---------------------------------------------------------------
    function applyFilter(category) {
        var shown = 0;
        figures.forEach(function (fig) {
            var match = category === "all" || fig.getAttribute("data-category") === category;
            fig.hidden = !match;
            if (match) { shown++; }
        });
        chips.forEach(function (c) { c.setAttribute("aria-pressed", String(c.getAttribute("data-filter") === category)); });
        countEl.textContent = "Showing " + shown + " of " + figures.length + " photos";
    }
    chips.forEach(function (chip) {
        chip.addEventListener("click", function () { applyFilter(chip.getAttribute("data-filter")); });
    });
    applyFilter("all");

    // ---------------------------------------------------------------
    // Lightbox
    // ---------------------------------------------------------------
    var dialog, imgEl, titleEl, captionEl, counterEl, stage;
    var current = 0, sequence = [], trigger = null;

    function visibleLinks() {
        return figures.filter(function (f) { return !f.hidden; }).map(function (f) { return $("a", f); });
    }

    function build() {
        counterEl = el("span", { "aria-live": "polite" });
        var closeBtn = el("button", { class: "lightbox-btn", type: "button", "aria-label": "Close photo viewer", text: "×" });
        var prev = el("button", { class: "lightbox-btn lightbox-prev", type: "button", "aria-label": "Previous photo", text: "‹" });
        var next = el("button", { class: "lightbox-btn lightbox-next", type: "button", "aria-label": "Next photo", text: "›" });
        imgEl = el("img", { alt: "" });
        stage = el("div", { class: "lightbox-stage" }, [prev, imgEl, next]);
        titleEl = el("strong");
        captionEl = el("span");

        dialog = el("dialog", { class: "lightbox", "aria-label": "Photo viewer" }, [
            el("div", { class: "lightbox-top" }, [counterEl, closeBtn]),
            stage,
            el("div", { class: "lightbox-caption" }, [titleEl, captionEl])
        ]);
        document.body.appendChild(dialog);

        closeBtn.addEventListener("click", function () { dialog.close(); });
        prev.addEventListener("click", function () { show(current - 1); });
        next.addEventListener("click", function () { show(current + 1); });
        imgEl.addEventListener("click", function () { imgEl.classList.toggle("is-zoomed"); });
        // Click on the dark area around the photo closes the viewer
        stage.addEventListener("click", function (e) { if (e.target === stage) { dialog.close(); } });
        dialog.addEventListener("keydown", function (e) {
            if (e.key === "ArrowLeft") { e.preventDefault(); show(current - 1); }
            if (e.key === "ArrowRight") { e.preventDefault(); show(current + 1); }
        });
        dialog.addEventListener("close", function () {
            imgEl.classList.remove("is-zoomed");
            if (trigger) { trigger.focus(); }
        });

        // Swipe left / right on touch screens
        var startX = null;
        stage.addEventListener("pointerdown", function (e) { startX = e.clientX; });
        stage.addEventListener("pointerup", function (e) {
            if (startX === null) { return; }
            var dx = e.clientX - startX;
            startX = null;
            if (Math.abs(dx) > 60) { show(current + (dx < 0 ? 1 : -1)); }
        });
    }

    function show(index) {
        var n = sequence.length;
        current = (index + n) % n;                       // wrap around
        var link = sequence[current];
        var thumb = $("img", link);
        imgEl.classList.remove("is-zoomed");
        imgEl.src = link.getAttribute("href");
        imgEl.alt = thumb ? thumb.alt : "";
        titleEl.textContent = link.getAttribute("data-title") || "";
        captionEl.textContent = link.getAttribute("data-caption") || "";
        counterEl.textContent = "Photo " + (current + 1) + " of " + n;

        // Preload the neighbouring photos so next/previous feels instant
        [current - 1, current + 1].forEach(function (i) {
            var preload = new Image();
            preload.src = sequence[(i + n) % n].getAttribute("href");
        });
    }

    grid.addEventListener("click", function (e) {
        var link = e.target.closest("a");
        if (!link || !grid.contains(link)) { return; }
        e.preventDefault();
        if (!dialog) { build(); }
        sequence = visibleLinks();
        trigger = link;
        show(sequence.indexOf(link));
        if (typeof dialog.showModal === "function") { dialog.showModal(); } else { dialog.setAttribute("open", ""); }
        $(".lightbox-btn", dialog).focus();
    });
})();
