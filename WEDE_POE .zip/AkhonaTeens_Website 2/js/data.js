// =====================================================
// Akhona Teens: content data used by the dynamic pages
// (programmes search, events listing, map, enquiry responses).
// Edit here to add or change programmes, events or locations.
// =====================================================
window.ATLF_DATA = {
  "programmes": [
    {
      "id": "personal-development",
      "title": "Personal Development Workshops",
      "category": "core",
      "image": null,
      "summary": "Confidence, self-awareness and life skills to help teenagers handle school, friendships and pressure.",
      "description": "An eight-week workshop series that helps teenagers understand who they are, set meaningful goals and build the confidence to speak up. Sessions mix group activities, reflection and one-on-one coaching.",
      "duration": "8 weeks",
      "weeks": 8,
      "schedule": "Tuesdays & Thursdays, 15:30–17:00",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "13–19",
      "highlights": [
        "Goal-setting and vision boards",
        "Managing peer pressure and stress",
        "Communication and public-speaking basics",
        "A personal reflection journal to keep"
      ],
      "tags": [
        "confidence",
        "life skills",
        "self-awareness",
        "wellbeing",
        "coaching"
      ],
      "intakes": [
        "2027-01-26",
        "2027-04-20",
        "2027-07-27",
        "2027-10-19"
      ]
    },
    {
      "id": "leadership-development",
      "title": "Leadership Development Circles",
      "category": "core",
      "image": "workshop",
      "summary": "Hands-on leadership training: teamwork, decision-making and leading change in your school and community.",
      "description": "Ten Saturday sessions where teens practise leadership instead of just hearing about it. Participants plan and run a small community project with the support of a trained mentor.",
      "duration": "10 weeks",
      "weeks": 10,
      "schedule": "Saturdays, 09:00–12:00",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "13–19",
      "highlights": [
        "Team challenges and problem-solving",
        "Planning a real community project",
        "Debating, listening and giving feedback",
        "Certificate of completion"
      ],
      "tags": [
        "leadership",
        "teamwork",
        "mentoring",
        "community project",
        "saturday"
      ],
      "intakes": [
        "2027-01-23",
        "2027-04-17",
        "2027-07-24",
        "2027-10-16"
      ],
      "imageBase": "images/teen-leadership-workshop-gauteng",
      "imageWidths": [
        480,
        800,
        1200
      ],
      "imageAlt": "Teenagers raising their hands during a leadership workshop run by Akhona Teens in Gauteng",
      "imageW": 1200,
      "imageH": 900
    },
    {
      "id": "financial-literacy",
      "title": "Financial Literacy Bootcamp",
      "category": "core",
      "image": null,
      "summary": "Budgeting, saving and smart money decisions explained in plain language for teenagers.",
      "description": "A four-week bootcamp that turns money into something teens can understand and control: needs versus wants, saving goals, bank accounts, debt traps and how to earn.",
      "duration": "4 weeks",
      "weeks": 4,
      "schedule": "Wednesdays, 15:30–17:30",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "13–19",
      "highlights": [
        "Building a simple monthly budget",
        "How banks, interest and debt really work",
        "Setting and tracking a savings goal",
        "Spotting scams and unsafe loans"
      ],
      "tags": [
        "money",
        "budgeting",
        "saving",
        "banking",
        "financial literacy"
      ],
      "intakes": [
        "2027-02-03",
        "2027-05-05",
        "2027-08-04",
        "2027-11-03"
      ]
    },
    {
      "id": "entrepreneurial-academy",
      "title": "Akhona Teens Entrepreneurial Academy",
      "category": "core",
      "image": null,
      "summary": "A six-week course that takes a teen business idea from first spark to a live pitch.",
      "description": "Teens work from idea generation through budgeting, marketing and pricing, then pitch their business to a panel of local business mentors at a graduation showcase.",
      "duration": "6 weeks",
      "weeks": 6,
      "schedule": "Saturdays, 09:00–13:00",
      "venues": [
        "Kempton Park"
      ],
      "cost": "Free",
      "ages": "14–19",
      "highlights": [
        "Finding and testing a business idea",
        "Costing, pricing and basic bookkeeping",
        "Marketing on a tiny budget",
        "Pitch day in front of business mentors"
      ],
      "tags": [
        "entrepreneurship",
        "business",
        "teenpreneur",
        "pitching",
        "marketing",
        "academy"
      ],
      "intakes": [
        "2027-02-06",
        "2027-05-08",
        "2027-08-07",
        "2027-10-23"
      ]
    },
    {
      "id": "one-on-one-mentorship",
      "title": "One-on-One Mentorship",
      "category": "core",
      "image": null,
      "summary": "A screened, trained mentor walks alongside a teenager for six months.",
      "description": "Every mentee is matched with a vetted adult mentor who meets with them twice a month. Mentors help teens set goals, make school and career choices and stay motivated.",
      "duration": "6 months",
      "weeks": 26,
      "schedule": "Two sessions a month (flexible times)",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "13–19",
      "highlights": [
        "Matched with a vetted, trained mentor",
        "Goal and career planning",
        "Homework and study support",
        "Check-ins by phone between sessions"
      ],
      "tags": [
        "mentor",
        "mentoring",
        "guidance",
        "career",
        "support"
      ],
      "intakes": [
        "2027-02-01",
        "2027-05-03",
        "2027-08-02",
        "2027-11-01"
      ]
    },
    {
      "id": "holiday-leadership-camp",
      "title": "School Holiday Leadership Camp",
      "category": "core",
      "image": null,
      "summary": "Three days of adventure, teamwork and leadership challenges during the school holidays.",
      "description": "A three-day day-camp packed with outdoor team challenges, creative workshops and leadership talks from young professionals. Lunch is provided every day.",
      "duration": "3 days",
      "weeks": 1,
      "schedule": "Three consecutive weekdays, 09:00–15:00",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free (lunch provided)",
      "ages": "13–19",
      "highlights": [
        "Outdoor team challenges",
        "Creative workshops and talent show",
        "Talks from young professionals",
        "Lunch and snacks every day"
      ],
      "tags": [
        "holiday",
        "camp",
        "adventure",
        "teamwork",
        "school holidays"
      ],
      "intakes": [
        "2026-12-08",
        "2027-03-30",
        "2027-06-29",
        "2027-09-28"
      ]
    },
    {
      "id": "thousand-ways-to-smile",
      "title": "A Thousand Ways to Smile",
      "category": "community",
      "image": "dignity",
      "summary": "Our dignity drive delivering sanitary products, toiletries and confidence workshops to girls in rural communities.",
      "description": "A Thousand Ways to Smile provides dignity packs and confidence-building workshops to girls in underserved communities, with a goal of reaching 10,000 girls across Gauteng and Mpumalanga. More than 4,600 girls have been reached so far.",
      "duration": "Ongoing campaign",
      "weeks": 52,
      "schedule": "Monthly distribution days",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "Girls 12–19",
      "highlights": [
        "Dignity packs with sanitary products and toiletries",
        "Confidence and health workshops",
        "Delivered through partner schools",
        "Volunteers and donors always welcome"
      ],
      "tags": [
        "dignity",
        "girls",
        "sanitary",
        "campaign",
        "donate",
        "rural"
      ],
      "intakes": [
        "2026-11-14",
        "2027-01-16",
        "2027-03-13",
        "2027-05-15"
      ],
      "imageBase": "images/dignity-packs-thousand-ways-to-smile",
      "imageWidths": [
        480,
        800,
        960
      ],
      "imageAlt": "Boxes of toothpaste, toothbrushes and soap on a trolley, packed for the A Thousand Ways to Smile dignity drive",
      "imageW": 960,
      "imageH": 1280
    },
    {
      "id": "hluvukani-innovation-hub",
      "title": "Hluvukani Innovation Hub",
      "category": "community",
      "image": null,
      "summary": "Computers, free internet and a creative study space for young people in Hluvukani, Mpumalanga.",
      "description": "The Innovation Hub gives learners somewhere to complete schoolwork, research bursaries, learn digital skills and build ideas, with trained volunteers on hand after school.",
      "duration": "Open all year",
      "weeks": 52,
      "schedule": "Mon–Fri 14:00–17:30, Sat 09:00–13:00",
      "venues": [
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "13–19",
      "highlights": [
        "Computers and free internet access",
        "Quiet study space and homework help",
        "Digital-skills workshops",
        "Bursary and career research support"
      ],
      "tags": [
        "computers",
        "internet",
        "digital skills",
        "study",
        "mpumalanga",
        "innovation hub"
      ],
      "intakes": [
        "2026-11-02",
        "2027-01-18",
        "2027-04-12",
        "2027-07-19"
      ]
    },
    {
      "id": "community-outreach",
      "title": "Community Outreach Visits",
      "category": "community",
      "image": "outreach",
      "summary": "Teen and adult volunteers visiting schools and early learning centres to read, play and serve.",
      "description": "Once a month our volunteers and programme graduates visit local schools and early-learning centres. Teens practise service leadership while younger children get time, attention and fun.",
      "duration": "Monthly",
      "weeks": 52,
      "schedule": "One Saturday a month, 09:00–12:00",
      "venues": [
        "Kempton Park",
        "Hluvukani"
      ],
      "cost": "Free",
      "ages": "Volunteers 16+",
      "highlights": [
        "Reading and play sessions with young children",
        "Service leadership for teen volunteers",
        "Donation drives for school supplies",
        "Open to families and groups"
      ],
      "tags": [
        "outreach",
        "volunteer",
        "children",
        "service",
        "community"
      ],
      "intakes": [
        "2026-11-21",
        "2027-02-20",
        "2027-03-27",
        "2027-04-24"
      ],
      "imageBase": "images/community-outreach-early-learning-centre",
      "imageWidths": [
        480,
        768
      ],
      "imageAlt": "Volunteers helping young children on colourful mats at an early learning centre during a community outreach visit",
      "imageW": 768,
      "imageH": 1024
    }
  ],
  "events": [
    {
      "id": "leadership-saturday-kickoff-2026",
      "title": "Leadership Saturday: Term 1 Kick-Off",
      "date": "2026-02-14",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "workshop",
      "summary": "The year's first leadership circle, with goal-setting, team games and a welcome braai.",
      "details": "New and returning teenagers met their mentors, set personal goals for the year and took on their first team challenge.",
      "tags": [
        "leadership",
        "term 1",
        "workshop"
      ]
    },
    {
      "id": "youth-day-dialogue-2026",
      "title": "Youth Day Leadership Dialogue",
      "date": "2026-06-16",
      "start": "10:00",
      "end": "14:00",
      "venue": "Hluvukani Innovation Hub",
      "loc": "hluvukani",
      "category": "community",
      "summary": "A community dialogue marking 50 years since the 1976 Youth Uprising and what leadership means today.",
      "details": "Teenagers, elders and local leaders shared stories and discussed how today's youth can lead change in their own communities.",
      "tags": [
        "youth day",
        "dialogue",
        "community"
      ]
    },
    {
      "id": "dignity-drive-womens-month-2026",
      "title": "Women's Month Dignity Drive",
      "date": "2026-08-08",
      "start": "09:00",
      "end": "13:00",
      "venue": "Hluvukani Innovation Hub",
      "loc": "hluvukani",
      "category": "campaign",
      "summary": "A Thousand Ways to Smile packed and handed out dignity packs to hundreds of girls.",
      "details": "Volunteers packed and distributed dignity packs and hosted a confidence workshop for girls from partner schools.",
      "tags": [
        "dignity",
        "campaign",
        "girls"
      ]
    },
    {
      "id": "academy-showcase-2026",
      "title": "Entrepreneurial Academy Graduation Showcase",
      "date": "2026-09-12",
      "start": "10:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "showcase",
      "summary": "Teen entrepreneurs pitched their businesses to a panel of local business mentors.",
      "details": "Graduates of the six-week Academy presented business ideas ranging from mobile car washes to handmade jewellery.",
      "tags": [
        "entrepreneurship",
        "showcase",
        "graduation"
      ]
    },
    {
      "id": "volunteer-orientation-nov-2026",
      "title": "Volunteer & Mentor Orientation Day",
      "date": "2026-11-07",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "orientation",
      "summary": "Meet the team, complete your safeguarding induction and learn how to mentor teenagers.",
      "details": "A relaxed half-day covering our safeguarding policy, how mentoring sessions work and where volunteers are needed most. Bring your ID document.",
      "tags": [
        "volunteer",
        "mentor",
        "orientation",
        "training"
      ]
    },
    {
      "id": "financial-literacy-saturday-nov-2026",
      "title": "Financial Literacy Saturday: Budgeting for Teens",
      "date": "2026-11-21",
      "start": "09:00",
      "end": "12:30",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "workshop",
      "summary": "A one-morning crash course in budgeting, saving and avoiding scams, open to all teens.",
      "details": "Teenagers build their first budget, compare banking options and learn how to spot online and loan scams. Snacks provided.",
      "tags": [
        "money",
        "budgeting",
        "workshop"
      ]
    },
    {
      "id": "year-end-celebration-2026",
      "title": "Year-End Leadership Celebration",
      "date": "2026-12-05",
      "start": "10:00",
      "end": "14:00",
      "venue": "Hluvukani Innovation Hub",
      "loc": "hluvukani",
      "category": "community",
      "summary": "Certificates, performances and a community lunch to celebrate the year's graduates.",
      "details": "Families and community members join us to celebrate everything our teenagers achieved this year, with performances, certificates and lunch.",
      "tags": [
        "celebration",
        "graduation",
        "community"
      ]
    },
    {
      "id": "new-intake-open-day-2027",
      "title": "New Intake Open Day",
      "date": "2027-01-23",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "open-day",
      "summary": "Parents and teens can tour our programmes, meet mentors and register for Term 1.",
      "details": "Meet the programme team, try a taster workshop and register for Term 1 programmes on the spot. Free entry.",
      "tags": [
        "registration",
        "open day",
        "enrolment"
      ]
    },
    {
      "id": "volunteer-orientation-jan-2027",
      "title": "Volunteer & Mentor Orientation Day (Term 1)",
      "date": "2027-01-30",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "orientation",
      "summary": "Orientation and safeguarding induction for new volunteers and mentors.",
      "details": "Our Term 1 orientation covers safeguarding, mentoring basics and volunteer placements.",
      "tags": [
        "volunteer",
        "mentor",
        "orientation"
      ]
    },
    {
      "id": "digital-skills-day-2027",
      "title": "Digital Skills Day at the Innovation Hub",
      "date": "2027-02-13",
      "start": "09:00",
      "end": "13:00",
      "venue": "Hluvukani Innovation Hub",
      "loc": "hluvukani",
      "category": "workshop",
      "summary": "CV writing, safe internet use and bursary applications for Hluvukani learners.",
      "details": "Learners practise typing, create an email address, write a CV and learn how to apply for bursaries online.",
      "tags": [
        "digital skills",
        "internet",
        "bursaries"
      ]
    },
    {
      "id": "dignity-walk-2027",
      "title": "Dignity Drive Fundraiser Walk",
      "date": "2027-03-20",
      "start": "07:30",
      "end": "11:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "fundraiser",
      "summary": "A family-friendly 5 km walk raising funds for A Thousand Ways to Smile.",
      "details": "Walk, jog or stroll to raise funds for dignity packs. Every R85 raised provides one dignity pack. Entry is by donation.",
      "tags": [
        "fundraiser",
        "dignity",
        "walk",
        "family"
      ]
    },
    {
      "id": "volunteer-orientation-apr-2027",
      "title": "Volunteer & Mentor Orientation Day (Term 2)",
      "date": "2027-04-24",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "orientation",
      "summary": "Orientation and safeguarding induction for Term 2 volunteers and mentors.",
      "details": "Join us for orientation before Term 2 programmes begin.",
      "tags": [
        "volunteer",
        "mentor",
        "orientation"
      ]
    },
    {
      "id": "teen-business-showcase-2027",
      "title": "Mid-Year Teen Business Showcase",
      "date": "2027-06-12",
      "start": "10:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "showcase",
      "summary": "Entrepreneurial Academy teens pitch live to investors and the public.",
      "details": "Come and support our teen entrepreneurs, buy from their stalls and vote for the People's Choice award.",
      "tags": [
        "entrepreneurship",
        "showcase",
        "pitch"
      ]
    },
    {
      "id": "volunteer-orientation-jul-2027",
      "title": "Volunteer & Mentor Orientation Day (Term 3)",
      "date": "2027-07-31",
      "start": "09:00",
      "end": "13:00",
      "venue": "Head Office – Kempton Park",
      "loc": "kempton",
      "category": "orientation",
      "summary": "Orientation and safeguarding induction for Term 3 volunteers and mentors.",
      "details": "Join us for orientation before Term 3 programmes begin.",
      "tags": [
        "volunteer",
        "mentor",
        "orientation"
      ]
    }
  ],
  "locations": [
    {
      "id": "kempton",
      "num": "1",
      "name": "Head Office – Kempton Park",
      "address": "14 Monument Road, Kempton Park, Gauteng, 1619",
      "lat": -26.1,
      "lng": 28.2333,
      "phone": "011 972 4456",
      "hours": "Monday–Friday, 08:00–16:30; workshops on Saturdays 09:00–13:00",
      "radiusKm": 25,
      "note": "Head office, Saturday leadership circles and the Entrepreneurial Academy."
    },
    {
      "id": "hluvukani",
      "num": "2",
      "name": "Hluvukani Innovation Hub",
      "address": "Hluvukani Community Centre, Hluvukani, Mpumalanga, 1363",
      "lat": -24.6456,
      "lng": 31.3498,
      "phone": "011 972 4456",
      "hours": "Monday–Friday, 14:00–17:30; Saturdays 09:00–13:00",
      "radiusKm": 40,
      "note": "Computers, free internet, study space and digital-skills workshops."
    }
  ],
  "orgEmail": "info@akhonateens.co.za"
};
