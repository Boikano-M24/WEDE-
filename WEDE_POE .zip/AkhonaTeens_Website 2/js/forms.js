// =====================================================================
// forms.js: reusable form tools shared by the enquiry and contact forms.
//
//   ATLF.forms.Validator  : validates a form field-by-field, shows clear
//                           error messages next to each field, builds an
//                           error summary, and re-validates as people type.
//   ATLF.forms.rules      : small reusable checks (required, email, SA phone,
//                           length, number range, date range, age ...).
//   ATLF.forms.sendAjax   : sends form data asynchronously with fetch().
//   ATLF.forms.counter    : live "123 / 600" character counters.
//
// Why custom validation as well as HTML5 attributes? The HTML attributes
// (required, minlength, type="email" ...) are still on every field, so the
// form degrades gracefully. JavaScript adds friendlier, consistent messages,
// cross-field rules (e.g. under-18s need a guardian) and accessibility
// features (aria-invalid, aria-describedby, focus on the first error).
// =====================================================================
(function () {
    "use strict";

    var ATLF = window.ATLF, utils = ATLF.utils, $ = utils.$, $$ = utils.$$;
    var forms = (ATLF.forms = {});

    // ------------------------------------------------------------------
    // RULES: each returns a function (value, allValues) -> error message or ""
    // ------------------------------------------------------------------
    forms.rules = {
        required: function (msg) {
            return function (v) {
                var empty = Array.isArray(v) ? v.length === 0 : v === null || v === undefined || String(v).trim() === "";
                return empty ? msg : "";
            };
        },
        minLength: function (n, msg) { return function (v) { return v && v.trim().length < n ? msg : ""; }; },
        maxLength: function (n, msg) { return function (v) { return v && v.length > n ? msg : ""; }; },
        pattern: function (re, msg) { return function (v) { return v && !re.test(v.trim()) ? msg : ""; }; },
        email: function (msg) {
            // Practical check: something@something.tld (no spaces, one @, dot in the domain)
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
            return function (v) { return v && !re.test(v.trim()) ? msg : ""; };
        },
        // South African numbers: 0821234567, 082 123 4567, +27 82 123 4567, 011-972-4456
        saPhone: function (msg) {
            return function (v) {
                if (!v) { return ""; }
                var digits = v.replace(/[\s\-()]/g, "");
                return /^(\+27|0)[1-9][0-9]{8}$/.test(digits) ? "" : msg;
            };
        },
        numberRange: function (min, max, msg) {
            return function (v) {
                if (v === "" || v === null || v === undefined) { return ""; }
                var n = Number(v);
                return isNaN(n) || n < min || n > max || Math.floor(n) !== n ? msg : "";
            };
        },
        // Date strings are "YYYY-MM-DD"
        dateRange: function (minISO, maxISO, msg) {
            return function (v) { return v && ((minISO && v < minISO) || (maxISO && v > maxISO)) ? msg : ""; };
        },
        validDate: function (msg) {
            return function (v) { return v && isNaN(utils.parseISO(v).getTime()) ? msg : ""; };
        },
        custom: function (fn) { return fn; }
    };

    // Age in whole years on a given day
    forms.ageOn = function (dobISO, onDate) {
        var dob = utils.parseISO(dobISO), age = onDate.getFullYear() - dob.getFullYear();
        var m = onDate.getMonth() - dob.getMonth();
        if (m < 0 || (m === 0 && onDate.getDate() < dob.getDate())) { age--; }
        return age;
    };

    // ------------------------------------------------------------------
    // VALIDATOR
    //   new Validator(form, getRules, { summary: element })
    //   getRules(values) -> { fieldName: [ruleFn, ruleFn, ...], ... }
    //   Rules are re-evaluated on every check so they can depend on other
    //   fields (e.g. guardian name required only when the teen is under 18).
    //   Fields inside a [hidden] block are skipped.
    // ------------------------------------------------------------------
    function Validator(form, getRules, options) {
        this.form = form;
        this.getRules = getRules;
        this.summary = options && options.summary;
        this.touched = {};
        var self = this;

        // Validate a field when the visitor leaves it; keep validating while typing once touched
        form.addEventListener("focusout", function (e) {
            var name = self.nameOf(e.target);
            if (name) { self.touched[name] = true; self.validateField(name); }
        });
        form.addEventListener("input", function (e) {
            var name = self.nameOf(e.target);
            if (name && self.touched[name]) { self.validateField(name); }
        });
        form.addEventListener("change", function (e) {
            var name = self.nameOf(e.target);
            if (name) { self.touched[name] = true; self.validateField(name); }
        });
    }

    Validator.prototype.nameOf = function (target) {
        return target && target.name && this.form.contains(target) && target.name !== "website" ? target.name : null;
    };

    // Collect values: text -> string, checkbox group -> array, radio -> string, single checkbox -> "yes"/""
    Validator.prototype.values = function () {
        var vals = {};
        var elements = this.form.elements;
        for (var i = 0; i < elements.length; i++) {
            var f = elements[i];
            if (!f.name || f.name === "website" || f.type === "submit" || f.type === "button") { continue; }
            if (f.type === "checkbox") {
                var group = this.form.querySelectorAll('input[type="checkbox"][name="' + f.name + '"]');
                if (group.length > 1) {
                    vals[f.name] = vals[f.name] || [];
                    if (f.checked) { vals[f.name].push(f.value); }
                } else { vals[f.name] = f.checked ? f.value : ""; }
            } else if (f.type === "radio") {
                if (f.checked) { vals[f.name] = f.value; } else if (!(f.name in vals)) { vals[f.name] = ""; }
            } else { vals[f.name] = f.value; }
        }
        return vals;
    };

    Validator.prototype.wrapperOf = function (name) {
        return this.form.querySelector('[data-field="' + name + '"]');
    };

    Validator.prototype.isActive = function (name) {
        var wrap = this.wrapperOf(name);
        return !!wrap && !wrap.closest("[hidden]");
    };

    Validator.prototype.setError = function (name, message) {
        var wrap = this.wrapperOf(name);
        if (!wrap) { return; }
        var errorEl = wrap.querySelector(".field-error");
        var controls = $$("input, select, textarea", wrap);
        // Show the green "valid" state only when the field actually has a value
        var hasValue = controls.some(function (c) {
            return c.type === "checkbox" || c.type === "radio" ? c.checked : c.value.trim() !== "";
        });
        wrap.classList.toggle("is-invalid", !!message);
        wrap.classList.toggle("is-valid", !message && this.touched[name] === true && hasValue);
        if (errorEl) { errorEl.textContent = message || ""; }
        controls.forEach(function (c) {
            if (message) { c.setAttribute("aria-invalid", "true"); } else { c.removeAttribute("aria-invalid"); }
        });
    };

    // Returns the error message for one field ("" if fine)
    Validator.prototype.validateField = function (name) {
        if (!this.isActive(name)) { this.setError(name, ""); return ""; }
        var values = this.values();
        var rules = this.getRules(values)[name] || [];
        var message = "";
        for (var i = 0; i < rules.length; i++) {
            message = rules[i](values[name], values);
            if (message) { break; }
        }
        this.setError(name, message);
        // A change here can change another field's rules (e.g. date of birth -> guardian)
        return message;
    };

    // Validate everything. Returns [{name, message}] and updates the summary.
    Validator.prototype.validateAll = function () {
        var self = this, errors = [];
        var names = Object.keys(this.getRules(this.values()));
        names.forEach(function (name) {
            self.touched[name] = true;
            var msg = self.validateField(name);
            if (msg) { errors.push({ name: name, message: msg }); }
        });
        this.showSummary(errors);
        return errors;
    };

    // Focus the first control with an error so keyboard / screen-reader users land on it
    Validator.prototype.focusField = function (name) {
        var wrap = this.wrapperOf(name);
        var ctl = wrap && (wrap.querySelector("[aria-invalid='true']") || wrap.querySelector("input, select, textarea"));
        if (ctl) { ctl.focus(); }
    };

    Validator.prototype.showSummary = function (errors) {
        var box = this.summary, self = this;
        if (!box) { return; }
        box.textContent = "";
        if (!errors.length) { box.hidden = true; return; }

        box.appendChild(utils.el("h3", { text: errors.length === 1 ? "Please fix 1 problem" : "Please fix " + errors.length + " problems" }));
        var ul = utils.el("ul");
        errors.forEach(function (err) {
            var a = utils.el("a", { href: "#", text: err.message });
            a.addEventListener("click", function (e) { e.preventDefault(); self.focusField(err.name); });
            ul.appendChild(utils.el("li", {}, [a]));
        });
        box.appendChild(ul);
        box.hidden = false;
        box.focus();
    };

    Validator.prototype.reset = function () {
        var self = this;
        this.form.reset();
        this.touched = {};
        $$("[data-field]", this.form).forEach(function (w) {
            self.setError(w.getAttribute("data-field"), "");
            w.classList.remove("is-valid");
        });
        if (this.summary) { this.summary.hidden = true; this.summary.textContent = ""; }
        $$("[data-counter-for]", this.form).forEach(function (c) { c.textContent = "0 / " + c.getAttribute("data-max"); });
    };

    forms.Validator = Validator;

    // ------------------------------------------------------------------
    // CHARACTER COUNTERS
    // ------------------------------------------------------------------
    forms.counter = function (form) {
        $$("[data-counter-for]", form).forEach(function (counter) {
            var field = document.getElementById(counter.getAttribute("data-counter-for"));
            var max = Number(counter.getAttribute("data-max"));
            function update() {
                var len = field.value.length;
                counter.textContent = len + " / " + max;
                counter.classList.toggle("is-near", len > max * 0.9);
            }
            field.addEventListener("input", update);
            update();
        });
    };

    // ------------------------------------------------------------------
    // AJAX: send data asynchronously (no page reload) with fetch().
    // Resolves { ok: true, status, data } or { ok: false, reason }.
    // Never rejects, so callers can always show clear feedback.
    // ------------------------------------------------------------------
    forms.sendAjax = function (payload) {
        var cfg = window.ATLF_CONFIG || {};
        if (!cfg.ajaxEndpoint) { return Promise.resolve({ ok: false, reason: "disabled" }); }
        if (!window.fetch) { return Promise.resolve({ ok: false, reason: "unsupported" }); }

        var controller = window.AbortController ? new AbortController() : null;
        var timer = controller ? setTimeout(function () { controller.abort(); }, cfg.ajaxTimeoutMs || 8000) : null;

        return fetch(cfg.ajaxEndpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Accept": "application/json" },
            body: JSON.stringify(payload),
            signal: controller ? controller.signal : undefined
        }).then(function (res) {
            if (timer) { clearTimeout(timer); }
            if (!res.ok) { return { ok: false, reason: "server", status: res.status }; }
            return res.json().then(function (data) { return { ok: true, status: res.status, data: data }; })
                              .catch(function () { return { ok: true, status: res.status, data: null }; });
        }).catch(function (err) {
            if (timer) { clearTimeout(timer); }
            return { ok: false, reason: err && err.name === "AbortError" ? "timeout" : "network" };
        });
    };

    // ------------------------------------------------------------------
    // SMALL SHARED HELPERS
    // ------------------------------------------------------------------
    // Reference number like ATLF-261107-4821
    forms.reference = function () {
        var d = new Date();
        var ymd = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
        return "ATLF-" + ymd + "-" + String(Math.floor(1000 + Math.random() * 9000));
    };

    // Build a mailto: link (subject/body are URL-encoded; line breaks as CRLF)
    forms.mailto = function (to, subject, body) {
        return "mailto:" + to + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body).replace(/%0A/g, "%0D%0A");
    };

    forms.copyText = function (text) {
        if (navigator.clipboard && window.isSecureContext) { return navigator.clipboard.writeText(text); }
        return new Promise(function (resolve, reject) {
            var ta = utils.el("textarea", { "aria-hidden": "true" });
            ta.value = text;
            ta.className = "hp";
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand("copy") ? resolve() : reject(); } catch (e) { reject(e); }
            ta.remove();
        });
    };
})();
