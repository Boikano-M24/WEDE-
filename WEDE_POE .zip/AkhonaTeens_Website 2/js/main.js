// =====================================================================
// main.js: shared behaviour for every page.
//
//   1. Utilities (ATLF.utils) used by the other scripts
//   2. Footer year, sticky-header shadow, back-to-top button
//   3. Mobile navigation (hamburger)
//   4. Scroll-reveal animations + animated number counters
//   5. Tabs (accessible, keyboard operable)
//   6. Accordion (FAQ)
//   7. Modal dialogs (ATLF.openModal) + [data-modal] buttons
//   8. Social share links
//
// Everything here is an enhancement: the pages remain readable if
// JavaScript is unavailable.
// =====================================================================
(function () {
    "use strict";

    var ATLF = (window.ATLF = window.ATLF || {});
    var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // ------------------------------------------------------------------
    // 1. UTILITIES
    // ------------------------------------------------------------------
    var utils = (ATLF.utils = {
        $: function (sel, root) { return (root || document).querySelector(sel); },
        $$: function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); },

        // Create an element: el("p", {class: "x", text: "Hi"}, [child, ...])
        // "text" is inserted with textContent, so user input can never inject HTML.
        el: function (tag, attrs, children) {
            var node = document.createElement(tag);
            Object.keys(attrs || {}).forEach(function (key) {
                if (key === "text") { node.textContent = attrs[key]; }
                else if (key === "class") { node.className = attrs[key]; }
                else if (attrs[key] !== false && attrs[key] !== null && attrs[key] !== undefined) { node.setAttribute(key, attrs[key]); }
            });
            (children || []).forEach(function (child) {
                if (child === null || child === undefined) { return; }
                node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
            });
            return node;
        },

        debounce: function (fn, wait) {
            var timer;
            return function () {
                var args = arguments, ctx = this;
                clearTimeout(timer);
                timer = setTimeout(function () { fn.apply(ctx, args); }, wait);
            };
        },

        escapeRegExp: function (s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); },

        // "2026-11-07" -> Date at local midnight (avoids time-zone shifts)
        parseISO: function (iso) {
            var p = iso.split("-").map(Number);
            return new Date(p[0], p[1] - 1, p[2]);
        },
        today: function () { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); },
        toISO: function (d) {
            var m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
            return d.getFullYear() + "-" + m + "-" + day;
        },
        formatDate: function (d, style) {
            var opts = style === "short"
                ? { day: "numeric", month: "short", year: "numeric" }
                : { weekday: "long", day: "numeric", month: "long", year: "numeric" };
            return d.toLocaleDateString("en-GB", opts);
        },
        // Add N working days (Mon-Fri) to a date
        addWorkingDays: function (d, n) {
            var r = new Date(d.getTime());
            while (n > 0) {
                r.setDate(r.getDate() + 1);
                if (r.getDay() !== 0 && r.getDay() !== 6) { n--; }
            }
            return r;
        },
        // Wrap matches of `query` inside `text` with <mark> (safe: builds DOM nodes)
        highlight: function (text, query) {
            var frag = document.createDocumentFragment();
            if (!query) { frag.appendChild(document.createTextNode(text)); return frag; }
            var re = new RegExp("(" + utils.escapeRegExp(query) + ")", "ig");
            text.split(re).forEach(function (part) {
                if (part.toLowerCase() === query.toLowerCase()) { frag.appendChild(utils.el("mark", { text: part })); }
                else if (part) { frag.appendChild(document.createTextNode(part)); }
            });
            return frag;
        }
    });

    var $ = utils.$, $$ = utils.$$;

    // ------------------------------------------------------------------
    // 2. FOOTER YEAR, HEADER SHADOW, BACK-TO-TOP
    // ------------------------------------------------------------------
    function initPageChrome() {
        var year = $("#current-year");
        if (year) { year.textContent = new Date().getFullYear(); }

        var header = $(".site-header");
        var topBtn = $(".back-to-top");

        function onScroll() {
            var y = window.scrollY || document.documentElement.scrollTop;
            if (header) { header.classList.toggle("is-scrolled", y > 8); }
            if (topBtn) { topBtn.classList.toggle("is-visible", y > 600); }
        }
        window.addEventListener("scroll", onScroll, { passive: true });
        onScroll();

        if (topBtn) {
            topBtn.addEventListener("click", function () {
                window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
                var main = $("#main");
                if (main) { main.focus({ preventScroll: true }); }
            });
        }
    }

    // ------------------------------------------------------------------
    // 3. MOBILE NAVIGATION
    // ------------------------------------------------------------------
    function initNav() {
        var toggle = $(".nav-toggle");
        var nav = $("#site-nav");
        if (!toggle || !nav) { return; }

        function setOpen(open) {
            toggle.setAttribute("aria-expanded", String(open));
            nav.classList.toggle("is-open", open);
        }

        toggle.addEventListener("click", function () {
            setOpen(toggle.getAttribute("aria-expanded") !== "true");
        });
        // Escape closes the menu and returns focus to the button
        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape" && nav.classList.contains("is-open")) { setOpen(false); toggle.focus(); }
        });
        // Choosing a link closes the menu (useful for same-page anchors)
        $$("a", nav).forEach(function (a) { a.addEventListener("click", function () { setOpen(false); }); });
        // Leaving the mobile layout resets the menu
        window.addEventListener("resize", utils.debounce(function () {
            if (window.innerWidth > 900) { setOpen(false); }
        }, 150));
    }

    // ------------------------------------------------------------------
    // 4. SCROLL REVEAL + COUNTERS
    // ------------------------------------------------------------------
    function animateCount(node) {
        var target = parseInt(node.getAttribute("data-count"), 10);
        var suffix = node.getAttribute("data-suffix") || "";
        if (isNaN(target)) { return; }
        if (reduceMotion) { node.textContent = target.toLocaleString("en-GB") + suffix; return; }
        var duration = 1500, start = null;
        function frame(ts) {
            if (start === null) { start = ts; }
            var t = Math.min((ts - start) / duration, 1);
            var eased = 1 - Math.pow(1 - t, 3);                       // ease-out cubic
            node.textContent = Math.round(target * eased).toLocaleString("en-GB") + (t === 1 ? suffix : "");
            if (t < 1) { requestAnimationFrame(frame); }
        }
        requestAnimationFrame(frame);
    }

    function initReveal() {
        var items = $$(".reveal");
        var counters = $$("[data-count]");

        if (!("IntersectionObserver" in window)) {
            items.forEach(function (n) { n.classList.add("is-visible"); });
            return;
        }
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) { return; }
                entry.target.classList.add("is-visible");
                $$("[data-count]", entry.target).forEach(animateCount);
                observer.unobserve(entry.target);
            });
        }, { threshold: 0.15, rootMargin: "0px 0px -40px 0px" });

        items.forEach(function (n) { observer.observe(n); });

        // Counters that are not inside a .reveal element
        var counterObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) { animateCount(entry.target); counterObserver.unobserve(entry.target); }
            });
        }, { threshold: 0.6 });
        counters.forEach(function (n) { if (!n.closest(".reveal")) { counterObserver.observe(n); } });
    }

    // ------------------------------------------------------------------
    // 5. TABS (WAI-ARIA pattern: arrow keys, Home, End)
    // ------------------------------------------------------------------
    function initTabs() {
        $$("[data-tabs]").forEach(function (root) {
            var tabs = $$('[role="tab"]', root);
            var panels = tabs.map(function (t) { return document.getElementById(t.getAttribute("aria-controls")); });

            function select(index, focus) {
                tabs.forEach(function (tab, i) {
                    var active = i === index;
                    tab.setAttribute("aria-selected", String(active));
                    tab.setAttribute("tabindex", active ? "0" : "-1");
                    panels[i].hidden = !active;
                });
                if (focus) { tabs[index].focus(); }
            }

            tabs.forEach(function (tab, i) {
                tab.addEventListener("click", function () { select(i, false); });
                tab.addEventListener("keydown", function (e) {
                    var n = tabs.length, next = null;
                    if (e.key === "ArrowRight") { next = (i + 1) % n; }
                    else if (e.key === "ArrowLeft") { next = (i - 1 + n) % n; }
                    else if (e.key === "Home") { next = 0; }
                    else if (e.key === "End") { next = n - 1; }
                    if (next !== null) { e.preventDefault(); select(next, true); }
                });
            });

            // Deep link: about.html#panel-values opens that tab
            var hash = window.location.hash.replace("#", "");
            var start = panels.findIndex(function (p) { return p.id === hash; });
            select(start > -1 ? start : 0, false);
        });
    }

    // ------------------------------------------------------------------
    // 6. ACCORDION
    // ------------------------------------------------------------------
    function initAccordions() {
        $$("[data-accordion]").forEach(function (root) {
            var triggers = $$(".accordion-trigger", root);
            triggers.forEach(function (btn) {
                var panel = document.getElementById(btn.getAttribute("aria-controls"));
                btn.addEventListener("click", function () {
                    var open = btn.getAttribute("aria-expanded") === "true";
                    btn.setAttribute("aria-expanded", String(!open));
                    panel.classList.toggle("is-open", !open);
                });
                btn.addEventListener("keydown", function (e) {
                    var i = triggers.indexOf(btn), next = null;
                    if (e.key === "ArrowDown") { next = (i + 1) % triggers.length; }
                    else if (e.key === "ArrowUp") { next = (i - 1 + triggers.length) % triggers.length; }
                    else if (e.key === "Home") { next = 0; }
                    else if (e.key === "End") { next = triggers.length - 1; }
                    if (next !== null) { e.preventDefault(); triggers[next].focus(); }
                });
            });
        });
    }

    // ------------------------------------------------------------------
    // 7. MODAL DIALOGS (native <dialog>: focus trap + Escape for free)
    // ------------------------------------------------------------------
    // ATLF.openModal({ title: "Text", content: Node, actions: [{label, href|onClick, kind}], trigger: Element })
    ATLF.openModal = function (opts) {
        var id = "modal-title-" + Date.now();
        var closeBtn = utils.el("button", { class: "modal-close", type: "button", "aria-label": "Close dialog", text: "×" });
        var dlg = utils.el("dialog", { class: "modal", "aria-labelledby": id }, [
            utils.el("div", { class: "modal-header" }, [utils.el("h2", { id: id, text: opts.title }), closeBtn]),
            utils.el("div", { class: "modal-body" }, [opts.content])
        ]);

        if (opts.actions && opts.actions.length) {
            var footer = utils.el("div", { class: "modal-footer" });
            opts.actions.forEach(function (a) {
                var cls = "btn btn--small " + (a.kind === "outline" ? "btn--outline" : a.kind === "dark" ? "btn--dark" : "btn--primary");
                var node = a.href
                    ? utils.el("a", { class: cls, href: a.href, text: a.label })
                    : utils.el("button", { class: cls, type: "button", text: a.label });
                if (a.onClick) { node.addEventListener("click", function (e) { a.onClick(e, node, dlg); }); }
                footer.appendChild(node);
            });
            dlg.appendChild(footer);
        }

        closeBtn.addEventListener("click", function () { dlg.close(); });
        // Clicking the dark backdrop (the dialog element itself) closes it
        dlg.addEventListener("click", function (e) { if (e.target === dlg) { dlg.close(); } });
        dlg.addEventListener("close", function () {
            dlg.remove();
            if (opts.trigger && document.contains(opts.trigger)) { opts.trigger.focus(); }
        });

        document.body.appendChild(dlg);
        if (typeof dlg.showModal === "function") { dlg.showModal(); } else { dlg.setAttribute("open", ""); }
        closeBtn.focus();
        return dlg;
    };

    // <button data-modal="template-id" data-modal-title="Title"> opens a <template> in a modal
    function initModalButtons() {
        document.addEventListener("click", function (e) {
            var btn = e.target.closest("[data-modal]");
            if (!btn) { return; }
            var tpl = document.getElementById(btn.getAttribute("data-modal"));
            if (!tpl || !tpl.content) { return; }
            ATLF.openModal({
                title: btn.getAttribute("data-modal-title") || btn.textContent,
                content: tpl.content.cloneNode(true),
                trigger: btn,
                actions: [{ label: "Get in touch", href: "contact.html", kind: "primary" }]
            });
        });
    }

    // ------------------------------------------------------------------
    // 8. SHARE LINKS: point them at the page being viewed (only on http/https)
    // ------------------------------------------------------------------
    function initShareLinks() {
        if (!/^https?:$/.test(window.location.protocol)) { return; }
        var url = encodeURIComponent(window.location.href.split("#")[0]);
        var text = encodeURIComponent(document.title);
        var map = {
            whatsapp: "https://wa.me/?text=" + text + "%20" + url,
            facebook: "https://www.facebook.com/sharer/sharer.php?u=" + url,
            x: "https://twitter.com/intent/tweet?url=" + url + "&text=" + text
        };
        $$("[data-share]").forEach(function (a) {
            var key = a.getAttribute("data-share");
            if (map[key]) { a.setAttribute("href", map[key]); }
        });
    }

    // ------------------------------------------------------------------
    document.addEventListener("DOMContentLoaded", function () {
        initPageChrome();
        initNav();
        initReveal();
        initTabs();
        initAccordions();
        initModalButtons();
        initShareLinks();
    });
})();
