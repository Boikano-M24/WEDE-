// =====================================================================
// contact.js: the general contact form.
//
//   1. Validates name, email, phone (South African format, required only if
//      the visitor wants a phone/WhatsApp reply), message type, reply method,
//      subject (5-100 characters) and message (20-1000 characters, live counter).
//   2. On a valid submit: shows a "preparing" state, sends the data with AJAX
//      (fetch) and COMPILES THE EMAIL: recipient, subject and body.
//   3. Shows the email for review with three actions:
//        - Open in my email app  (mailto: link addressed to the recipient in
//                                 js/config.js, subject and body filled in)
//        - Copy email text       (for webmail users)
//        - Edit my message       (back to the form, nothing is lost)
//
// A static website cannot send mail by itself, so the visitor's own email app
// does the final send. The recipient is set in js/config.js.
// =====================================================================
(function () {
    "use strict";

    var ATLF = window.ATLF, utils = ATLF.utils, forms = ATLF.forms, R = forms.rules;
    var $ = utils.$, el = utils.el;

    var form = $("#contact-form");
    if (!form) { return; }

    var cfg = window.ATLF_CONFIG || {};
    var recipient = cfg.recipientEmail || "info@akhonateens.co.za";
    var statusEl = $("#contact-status"), submitBtn = $("#contact-submit"), responseBox = $("#contact-response");

    var TYPE_LABEL = { general: "General question", programme: "Question about a programme", media: "Media enquiry",
                       feedback: "Feedback or compliment", complaint: "Complaint", other: "Something else" };
    var METHOD_LABEL = { email: "Email", phone: "Phone call", whatsapp: "WhatsApp" };
    var TIME_LABEL = { morning: "Morning (08:00–12:00)", afternoon: "Afternoon (12:00–16:30)", any: "Any time", "": "Not specified" };

    // ------------------------------------------------------------------
    // VALIDATION
    // ------------------------------------------------------------------
    function getRules() {
        return {
            name: [R.required("Please enter your full name."), R.minLength(2, "Your name must be at least 2 characters."),
                   R.maxLength(60, "Your name must be 60 characters or fewer."),
                   R.pattern(/^[\p{L}][\p{L}\s'’.\-]*$/u, "Use letters, spaces, hyphens and apostrophes only.")],
            email: [R.required("Please enter your email address."), R.email("Enter a valid email address, for example name@example.com.")],
            phone: [R.saPhone("Enter a valid South African number, for example 082 123 4567."),
                    R.custom(function (val, all) {
                        var needs = all.contactMethod === "phone" || all.contactMethod === "whatsapp";
                        return needs && !val.trim() ? "Please enter a phone number so we can reach you by " + (all.contactMethod === "phone" ? "phone." : "WhatsApp.") : "";
                    })],
            messageType: [R.required("Please choose the type of message.")],
            contactMethod: [R.required("Please choose how we should reply.")],
            subject: [R.required("Please enter a subject."), R.minLength(5, "The subject must be at least 5 characters."),
                      R.maxLength(100, "The subject must be 100 characters or fewer.")],
            message: [R.required("Please write your message."),
                      R.custom(function (val) {
                          var n = val.trim().length;
                          return n > 0 && n < 20 ? "Please write at least 20 characters so we can help you properly (you have " + n + ")." : "";
                      }),
                      R.maxLength(1000, "Please keep your message to 1000 characters or fewer.")],
            consent: [R.required("Please tick the box to agree before sending.")]
        };
    }

    var validator = new forms.Validator(form, getRules, { summary: $("#contact-summary") });
    forms.counter(form);

    // The phone rule depends on the chosen reply method
    form.addEventListener("change", function (e) {
        if (e.target.name === "contactMethod" && validator.touched.phone) { validator.validateField("phone"); }
    });

    // ------------------------------------------------------------------
    // COMPILE THE EMAIL
    // ------------------------------------------------------------------
    function compile(v) {
        var sent = utils.formatDate(new Date());
        var body = [
            "Hello Akhona Teens team,", "",
            v.message.trim(), "",
            "-----------------------------",
            "Name: " + v.name,
            "Email: " + v.email,
            "Phone: " + (v.phone.trim() || "not provided"),
            "Preferred reply method: " + METHOD_LABEL[v.contactMethod],
            "Best time to reach me: " + TIME_LABEL[v.bestTime || ""],
            "Type of message: " + TYPE_LABEL[v.messageType],
            "Sent from the Akhona Teens website contact form on " + sent + "."
        ].join("\n");
        return { to: recipient, subject: "[Website: " + TYPE_LABEL[v.messageType] + "] " + v.subject.trim(), body: body };
    }

    // ------------------------------------------------------------------
    // RENDER THE EMAIL PREVIEW
    // ------------------------------------------------------------------
    function setStatus(text, kind, spinner) {
        statusEl.textContent = "";
        statusEl.className = "form-status" + (kind ? " is-" + kind : "");
        if (spinner) { statusEl.appendChild(el("span", { class: "spinner", "aria-hidden": "true" })); }
        statusEl.appendChild(document.createTextNode(text));
    }

    function renderPreview(mail, ajax) {
        responseBox.textContent = "";
        responseBox.appendChild(el("h2", { text: "Your email is ready to send" }));
        responseBox.appendChild(el("p", { class: "lede", text: "We have checked your details and compiled your message into an email addressed to " + mail.to + "." }));

        var preview = el("div", { class: "email-preview" }, [
            el("dl", {}, [el("dt", { text: "To" }), el("dd", { text: mail.to }), el("dt", { text: "Subject" }), el("dd", { text: mail.subject })]),
            el("pre", { text: mail.body })
        ]);
        responseBox.appendChild(preview);

        var note = ajax.ok
            ? "Your message was also submitted successfully" + (ajax.data && ajax.data.id ? " (confirmation #" + ajax.data.id + ")." : ".")
            : ajax.reason === "disabled" ? "" : "We could not reach the server just now (" + ajax.reason + "). Sending from your email app below still works.";
        if (note) { responseBox.appendChild(el("p", { class: "form-status " + (ajax.ok ? "is-ok" : "is-error"), role: "status", text: note })); }

        var sendLink = el("a", { class: "btn btn--primary", href: forms.mailto(mail.to, mail.subject, mail.body), text: "Open in my email app" });
        var feedback = el("p", { class: "form-status", role: "status" });
        sendLink.addEventListener("click", function () {
            feedback.className = "form-status is-ok";
            feedback.textContent = "Your email app should open with the message ready. Press Send there to finish. If nothing opens, use “Copy email text” and paste it into your email.";
        });

        var copyBtn = el("button", { class: "btn btn--outline", type: "button", text: "Copy email text" });
        copyBtn.addEventListener("click", function () {
            forms.copyText("To: " + mail.to + "\nSubject: " + mail.subject + "\n\n" + mail.body).then(function () {
                feedback.className = "form-status is-ok";
                feedback.textContent = "Copied. Paste it into a new email to " + mail.to + ".";
            }, function () {
                feedback.className = "form-status is-error";
                feedback.textContent = "Copying was blocked by your browser. Please select the text above and copy it manually.";
            });
        });

        var editBtn = el("button", { class: "btn btn--outline", type: "button", text: "Edit my message" });
        editBtn.addEventListener("click", function () {
            responseBox.hidden = true; form.hidden = false;
            $("#message").focus();
        });

        responseBox.appendChild(el("div", { class: "cta-row" }, [sendLink, copyBtn, editBtn]));
        responseBox.appendChild(feedback);

        form.hidden = true;
        responseBox.hidden = false;
        responseBox.focus();
        responseBox.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
    }

    // ------------------------------------------------------------------
    // SUBMIT
    // ------------------------------------------------------------------
    var busy = false;
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        if (busy) { return; }

        var errors = validator.validateAll();
        if (errors.length) { setStatus("Please correct the highlighted fields and try again.", "error"); return; }

        // Honeypot (hidden from people; bots tend to fill it)
        if (form.elements.website && form.elements.website.value) { setStatus("Thank you!", "ok"); return; }

        busy = true;
        submitBtn.disabled = true;
        setStatus("Preparing your email…", "", true);

        var values = validator.values();
        var mail = compile(values);
        var payload = Object.assign({ submittedAt: new Date().toISOString(), page: "contact" }, values);

        Promise.all([forms.sendAjax(payload), new Promise(function (r) { setTimeout(r, 500); })]).then(function (out) {
            renderPreview(mail, out[0]);
            setStatus("", "");
            busy = false;
            submitBtn.disabled = false;
        });
    });
})();
