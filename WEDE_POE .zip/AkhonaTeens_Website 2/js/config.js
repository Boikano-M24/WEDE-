// =====================================================
// config.js: settings for the forms (enquiry + contact).
// Change the values below; no other file needs editing.
// =====================================================
window.ATLF_CONFIG = {

    // Where compiled emails are addressed. The "Send email" button opens
    // the visitor's email app with this recipient already filled in.
    // TIP: while testing, replace this with your own address.
    recipientEmail: "info@akhonateens.co.za",

    // AJAX endpoint: the forms send their data here asynchronously (fetch).
    // jsonplaceholder.typicode.com is a free public TESTING service: it accepts
    // a POST, echoes the data back with an id, and does not store or email it.
    // For real delivery, swap it for a form service, e.g.
    //   "https://formsubmit.co/ajax/your-address@example.com"
    // Set to "" to switch AJAX off (the compiled email option still works).
    ajaxEndpoint: "https://jsonplaceholder.typicode.com/posts",

    // How long to wait for the AJAX request before giving up (milliseconds)
    ajaxTimeoutMs: 8000,

    // Cost of impact items shown in sponsorship responses (rand)
    costs: {
        dignityPack: 85,        // one A Thousand Ways to Smile pack
        academySeat: 1200,      // one teen's place on the Entrepreneurial Academy
        hubMonth: 3500          // monthly running cost of the Innovation Hub
    }
};
