// =====================================================
// init.js: runs first (in <head>, before the page is drawn).
// Adds a "js" class to <html> so the stylesheet can tell that
// JavaScript is available. Without JavaScript the pages still
// show all their content (progressive enhancement).
// =====================================================
document.documentElement.classList.add("js");
