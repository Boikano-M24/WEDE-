// =====================================================================
// events.js: dynamic events.
//
//   * Home page  : shows the next three upcoming events (#home-events).
//   * Events page: full list (#event-list) with search, type filter,
//                  upcoming/past chips, three sort orders, "load more"
//                  pagination, a details modal and "Add to calendar" (.ics).
//   * Data comes from ATLF_DATA.events (js/data.js). "Upcoming" is worked
//     out from today's date, so the list keeps itself current.
// =====================================================================
(function () {
    "use strict";

    var ATLF = window.ATLF, utils = ATLF.utils, el = utils.el, $ = utils.$;
    if (!window.ATLF_DATA) { return; }

    var events = window.ATLF_DATA.events.map(function (e) {
        var copy = Object.assign({}, e);
        copy.dateObj = utils.parseISO(e.date);
        return copy;
    });
    var today = utils.today();
    var PAGE_SIZE = 6;

    function isUpcoming(e) { return e.dateObj >= today; }
    function label(cat) { return cat.replace(/-/g, " ").replace(/\b\w/g, function (c) { return c.toUpperCase(); }); }

    // ---------- Add to calendar (.ics file generated in the browser) ----------
    function icsStamp(e, time) { return e.date.replace(/-/g, "") + "T" + time.replace(":", "") + "00"; }
    function icsText(s) { return s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n"); }

    function downloadICS(e) {
        var lines = [
            "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Akhona Teens Leadership Foundation//Website//EN", "CALSCALE:GREGORIAN",
            "BEGIN:VEVENT",
            "UID:" + e.id + "@akhonateens",
            "DTSTAMP:" + new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z",
            "DTSTART:" + icsStamp(e, e.start),
            "DTEND:" + icsStamp(e, e.end),
            "SUMMARY:" + icsText(e.title),
            "LOCATION:" + icsText(e.venue),
            "DESCRIPTION:" + icsText(e.details),
            "END:VEVENT", "END:VCALENDAR"
        ];
        var blob = new Blob([lines.join("\r\n")], { type: "text/calendar;charset=utf-8" });
        var url = URL.createObjectURL(blob);
        var a = el("a", { href: url, download: e.id + ".ics" });
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    }

    // ---------- Event card ----------
    function buildCard(e, query, index) {
        var past = !isUpcoming(e);
        var card = el("article", { class: "card event-card" + (past ? " event-card--past" : "") });
        card.style.animationDelay = Math.min(index, 6) * 0.05 + "s";

        var badge = el("div", { class: "date-badge", "aria-hidden": "true" }, [
            el("span", { class: "month", text: e.dateObj.toLocaleDateString("en-GB", { month: "short" }) }),
            el("span", { class: "day", text: String(e.dateObj.getDate()) }),
            el("span", { class: "year", text: String(e.dateObj.getFullYear()) })
        ]);

        var title = el("h3"); title.appendChild(utils.highlight(e.title, query));
        var summary = el("p"); summary.appendChild(utils.highlight(e.summary, query));

        var detailsBtn = el("button", { class: "btn btn--dark btn--small", type: "button", text: "Details" });
        detailsBtn.setAttribute("aria-label", "Details: " + e.title);
        detailsBtn.addEventListener("click", function () { openDetails(e, detailsBtn); });

        var actions = el("div", { class: "prog-actions" }, [detailsBtn]);
        if (!past) {
            var cal = el("button", { class: "btn btn--outline btn--small", type: "button", text: "Add to calendar" });
            cal.setAttribute("aria-label", "Add to calendar: " + e.title);
            cal.addEventListener("click", function () { downloadICS(e); });
            actions.appendChild(cal);
        }

        card.appendChild(badge);
        card.appendChild(el("div", { class: "event-body" }, [
            el("div", { class: "event-tags" }, [
                el("span", { class: "badge", text: label(e.category) }),
                el("span", { class: "badge " + (past ? "badge--past" : "badge--upcoming"), text: past ? "Past event" : "Upcoming" })
            ]),
            title,
            el("p", { class: "prog-meta" }, [
                el("span", { text: utils.formatDate(e.dateObj, "short") + ", " + e.start + "–" + e.end }),
                el("span", { text: e.venue })
            ]),
            summary,
            actions
        ]));
        return card;
    }

    function openDetails(e, trigger) {
        var past = !isUpcoming(e);
        var facts = el("dl", { class: "facts" });
        [["Date", utils.formatDate(e.dateObj)], ["Time", e.start + " – " + e.end], ["Venue", e.venue], ["Cost", "Free to attend"]].forEach(function (r) {
            facts.appendChild(el("dt", { text: r[0] })); facts.appendChild(el("dd", { text: r[1] }));
        });
        var actions = [];
        if (!past) {
            actions.push({ label: "Add to calendar", kind: "primary", onClick: function () { downloadICS(e); } });
            var isOrientation = e.category === "orientation";
            actions.push({ label: isOrientation ? "Register as a volunteer" : "Ask a question", kind: "dark",
                           href: isOrientation ? "enquiry.html?type=volunteer" : "contact.html" });
        }
        actions.push({ label: "Find the venue", href: "contact.html#locations", kind: "outline" });

        ATLF.openModal({
            title: e.title, trigger: trigger, actions: actions,
            content: el("div", {}, [el("p", { text: e.details }), facts])
        });
    }

    // =====================================================================
    // HOME PAGE PREVIEW
    // =====================================================================
    var home = $("#home-events");
    if (home) {
        document.addEventListener("DOMContentLoaded", function () {
            var next = events.filter(isUpcoming).sort(function (a, b) { return a.dateObj - b.dateObj; }).slice(0, 3);
            home.textContent = "";
            if (!next.length) {
                home.appendChild(el("p", { text: "New events are being scheduled. Please check back soon." }));
                return;
            }
            next.forEach(function (e, i) { home.appendChild(buildCard(e, "", i)); });
        });
        return;
    }

    // =====================================================================
    // EVENTS PAGE
    // =====================================================================
    var list = $("#event-list");
    if (!list) { return; }

    var searchInput = $("#event-search"), catSelect = $("#event-category"), sortSelect = $("#event-sort");
    var countEl = $("#event-count"), resetBtn = $("#event-reset"), moreBtn = $("#event-more");
    var chips = utils.$$(".chip[data-when]");
    var state = { query: "", when: "upcoming", category: "all", sort: "asc", shown: PAGE_SIZE };

    function filtered() {
        var words = state.query.toLowerCase().split(/\s+/).filter(Boolean);
        var result = events.filter(function (e) {
            if (state.when === "upcoming" && !isUpcoming(e)) { return false; }
            if (state.when === "past" && isUpcoming(e)) { return false; }
            if (state.category !== "all" && e.category !== state.category) { return false; }
            var hay = [e.title, e.summary, e.details, e.venue, e.category, e.tags.join(" "),
                       utils.formatDate(e.dateObj)].join(" ").toLowerCase();
            return words.every(function (w) { return hay.indexOf(w) > -1; });
        });
        var sorters = {
            asc: function (a, b) { return a.dateObj - b.dateObj; },
            desc: function (a, b) { return b.dateObj - a.dateObj; },
            az: function (a, b) { return a.title.localeCompare(b.title); }
        };
        return result.sort(sorters[state.sort]);
    }

    function render() {
        var all = filtered();
        var visible = all.slice(0, state.shown);
        list.textContent = "";

        if (!all.length) {
            var reset = el("button", { class: "btn btn--dark btn--small", type: "button", text: "Clear search & filters" });
            reset.addEventListener("click", resetAll);
            list.appendChild(el("div", { class: "empty-state" }, [
                el("h3", { text: "No events found" }),
                el("p", { text: "Try another word such as “orientation”, “Hluvukani” or “walk”, or show all events." }),
                reset
            ]));
        } else {
            visible.forEach(function (e, i) { list.appendChild(buildCard(e, state.query, i)); });
        }

        countEl.textContent = all.length
            ? "Showing " + visible.length + " of " + all.length + " event" + (all.length === 1 ? "" : "s")
            : "No events found";
        var remaining = all.length - visible.length;
        moreBtn.hidden = remaining <= 0;
        moreBtn.textContent = "Load more events (" + remaining + " remaining)";
        resetBtn.hidden = !(state.query || state.category !== "all" || state.when !== "upcoming");
        chips.forEach(function (c) { c.setAttribute("aria-pressed", String(c.getAttribute("data-when") === state.when)); });
    }

    function resetAll() {
        state = { query: "", when: "upcoming", category: "all", sort: "asc", shown: PAGE_SIZE };
        searchInput.value = ""; catSelect.value = "all"; sortSelect.value = "asc";
        render();
        searchInput.focus();
    }

    searchInput.addEventListener("input", utils.debounce(function () { state.query = searchInput.value.trim(); state.shown = PAGE_SIZE; render(); }, 180));
    catSelect.addEventListener("change", function () { state.category = catSelect.value; state.shown = PAGE_SIZE; render(); });
    sortSelect.addEventListener("change", function () { state.sort = sortSelect.value; state.shown = PAGE_SIZE; render(); });
    chips.forEach(function (chip) {
        chip.addEventListener("click", function () {
            state.when = chip.getAttribute("data-when");
            // Past events read best newest-first; upcoming ones soonest-first
            if (state.when === "past") { state.sort = "desc"; } else if (state.when === "upcoming") { state.sort = "asc"; }
            sortSelect.value = state.sort;
            state.shown = PAGE_SIZE;
            render();
        });
    });
    moreBtn.addEventListener("click", function () {
        var before = state.shown;
        state.shown += PAGE_SIZE;
        render();
        // Move keyboard focus to the first newly-added card
        var cards = utils.$$(".event-card", list);
        if (cards[before]) { var b = $("button", cards[before]); if (b) { b.focus(); } }
    });
    resetBtn.addEventListener("click", resetAll);

    document.addEventListener("DOMContentLoaded", render);
})();
