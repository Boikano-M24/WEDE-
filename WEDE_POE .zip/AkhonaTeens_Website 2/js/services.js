// =====================================================================
// services.js: dynamic programme listing.
//
//   * Programmes come from ATLF_DATA (js/data.js) and are built with
//     DOM methods (no innerHTML), so the page is safe from injected HTML.
//   * Search (multi-word, matches title/summary/tags/venue), category chips,
//     venue filter and five sort orders.
//   * Matches are highlighted; the result count is announced to screen readers.
//   * "View details" opens a modal; "Enquire" deep-links into the enquiry form.
//   * State is kept in the URL (?q=...&category=...) so a search can be shared.
// =====================================================================
(function () {
    "use strict";

    var ATLF = window.ATLF, utils = ATLF.utils, el = utils.el, $ = utils.$;
    var list = $("#prog-list");
    if (!list || !window.ATLF_DATA) { return; }

    var programmes = window.ATLF_DATA.programmes;
    var CATEGORY_LABEL = { core: "Core programme", community: "Community initiative" };

    var searchInput = $("#prog-search"), sortSelect = $("#prog-sort"), venueSelect = $("#prog-venue");
    var countEl = $("#prog-count"), resetBtn = $("#prog-reset");
    var chips = utils.$$(".chip[data-category]");

    var state = { query: "", category: "all", venue: "all", sort: "intake" };

    // ---------- helpers ----------
    function nextIntake(p) {
        var todayISO = utils.toISO(utils.today());
        var future = (p.intakes || []).filter(function (d) { return d >= todayISO; }).sort();
        return future.length ? utils.parseISO(future[0]) : null;
    }

    function initials(title) {
        return title.split(/\s+/).filter(function (w) { return /^[A-Za-z]/.test(w) && w.length > 2; })
            .slice(0, 2).map(function (w) { return w[0].toUpperCase(); }).join("");
    }

    function enquiryLink(p) {
        if (p.id === "thousand-ways-to-smile") { return "enquiry.html?type=sponsor&cause=dignity"; }
        if (p.id === "community-outreach") { return "enquiry.html?type=volunteer"; }
        return "enquiry.html?type=enrolment&programme=" + encodeURIComponent(p.id);
    }

    function haystack(p) {
        return [p.title, p.summary, p.description, (p.tags || []).join(" "), p.venues.join(" "), CATEGORY_LABEL[p.category]]
            .join(" ").toLowerCase();
    }

    // ---------- filtering + sorting ----------
    function visibleProgrammes() {
        var words = state.query.toLowerCase().split(/\s+/).filter(Boolean);
        var result = programmes.filter(function (p) {
            if (state.category !== "all" && p.category !== state.category) { return false; }
            if (state.venue !== "all" && p.venues.indexOf(state.venue) === -1) { return false; }
            var hay = haystack(p);
            return words.every(function (w) { return hay.indexOf(w) > -1; });
        });

        var sorters = {
            intake: function (a, b) {
                var da = nextIntake(a), db = nextIntake(b);
                if (!da && !db) { return 0; }
                if (!da) { return 1; }
                if (!db) { return -1; }
                return da - db;
            },
            az: function (a, b) { return a.title.localeCompare(b.title); },
            za: function (a, b) { return b.title.localeCompare(a.title); },
            short: function (a, b) { return a.weeks - b.weeks; },
            long: function (a, b) { return b.weeks - a.weeks; }
        };
        return result.sort(sorters[state.sort]);
    }

    // ---------- rendering ----------
    function buildMedia(p) {
        var media = el("div", { class: "prog-media" + (p.category === "community" ? " prog-media--community" : "") });
        if (p.imageBase) {
            var jpg = p.imageWidths.map(function (w) { return p.imageBase + "-" + w + "w.jpg " + w + "w"; }).join(", ");
            var webp = p.imageWidths.map(function (w) { return p.imageBase + "-" + w + "w.webp " + w + "w"; }).join(", ");
            var sizes = "(max-width: 600px) 100vw, 340px";
            media.appendChild(el("picture", {}, [
                el("source", { type: "image/webp", srcset: webp, sizes: sizes }),
                el("img", { class: p.imageH > p.imageW ? "is-portrait" : "", src: p.imageBase + "-" + p.imageWidths[Math.min(1, p.imageWidths.length - 1)] + "w.jpg", srcset: jpg, sizes: sizes,
                            width: p.imageW, height: p.imageH, alt: p.imageAlt, loading: "lazy", decoding: "async" })
            ]));
        } else {
            media.appendChild(el("span", { "aria-hidden": "true", text: initials(p.title) }));
        }
        return media;
    }

    function buildCard(p, index) {
        var ni = nextIntake(p);
        var card = el("article", { class: "card prog-card" });
        card.style.animationDelay = Math.min(index, 8) * 0.05 + "s";

        var title = el("h3");
        title.appendChild(utils.highlight(p.title, state.query));
        var summary = el("p");
        summary.appendChild(utils.highlight(p.summary, state.query));

        var meta = el("div", { class: "prog-meta" }, [
            el("span", {}, [el("strong", { text: "Duration: " }), p.duration]),
            el("span", {}, [el("strong", { text: "Where: " }), p.venues.join(", ")]),
            el("span", {}, [el("strong", { text: "Ages: " }), p.ages]),
            el("span", {}, [el("strong", { text: "Cost: " }), p.cost])
        ]);
        var nextLine = el("p", { class: "prog-meta" }, [
            el("span", {}, [el("strong", { text: "Next start: " }), ni ? utils.formatDate(ni, "short") : "Contact us for dates"])
        ]);

        var detailsBtn = el("button", { class: "btn btn--dark btn--small", type: "button", text: "View details" });
        detailsBtn.setAttribute("aria-label", "View details: " + p.title);
        detailsBtn.addEventListener("click", function () { openDetails(p, detailsBtn); });

        var enquire = el("a", { class: "btn btn--primary btn--small", href: enquiryLink(p), text: p.id === "thousand-ways-to-smile" ? "Sponsor" : p.id === "community-outreach" ? "Volunteer" : "Enquire" });
        enquire.setAttribute("aria-label", enquire.textContent + ": " + p.title);

        card.appendChild(buildMedia(p));
        card.appendChild(el("div", { class: "prog-body" }, [
            el("span", { class: "badge" + (p.category === "community" ? " badge--community" : "") , text: CATEGORY_LABEL[p.category] }),
            title, summary, meta, nextLine,
            el("div", { class: "prog-actions" }, [detailsBtn, enquire])
        ]));
        return card;
    }

    function openDetails(p, trigger) {
        var ni = nextIntake(p);
        var facts = el("dl", { class: "facts" });
        [["Duration", p.duration], ["Schedule", p.schedule], ["Venues", p.venues.join(", ")], ["Ages", p.ages],
         ["Cost", p.cost], ["Next start", ni ? utils.formatDate(ni) : "Contact us for dates"]].forEach(function (row) {
            facts.appendChild(el("dt", { text: row[0] }));
            facts.appendChild(el("dd", { text: row[1] }));
        });
        var bullets = el("ul", { class: "bullets" }, p.highlights.map(function (h) { return el("li", { text: h }); }));
        var content = el("div", {}, [el("p", { text: p.description }), facts, el("h3", { text: "What's included" }), bullets]);

        ATLF.openModal({
            title: p.title, content: content, trigger: trigger,
            actions: [
                { label: p.id === "thousand-ways-to-smile" ? "Sponsor this campaign" : p.id === "community-outreach" ? "Volunteer" : "Enquire about this programme", href: enquiryLink(p), kind: "primary" },
                { label: "See upcoming events", href: "events.html", kind: "outline" }
            ]
        });
    }

    function render() {
        var items = visibleProgrammes();
        list.textContent = "";

        if (!items.length) {
            var reset = el("button", { class: "btn btn--dark btn--small", type: "button", text: "Clear search & filters" });
            reset.addEventListener("click", resetAll);
            list.appendChild(el("div", { class: "empty-state" }, [
                el("h3", { text: "No programmes match your search" }),
                el("p", { text: "Try a different word such as “money”, “leadership” or “mentor”, or clear the filters." }),
                reset
            ]));
        } else {
            items.forEach(function (p, i) { list.appendChild(buildCard(p, i)); });
        }

        countEl.textContent = items.length
            ? "Showing " + items.length + " of " + programmes.length + " programmes"
            : "No programmes found";
        var filtered = state.query || state.category !== "all" || state.venue !== "all";
        resetBtn.hidden = !filtered;

        chips.forEach(function (c) { c.setAttribute("aria-pressed", String(c.getAttribute("data-category") === state.category)); });
        saveToURL();
    }

    // ---------- state <-> controls / URL ----------
    function resetAll() {
        state = { query: "", category: "all", venue: "all", sort: state.sort };
        searchInput.value = ""; venueSelect.value = "all";
        render();
        searchInput.focus();
    }

    function saveToURL() {
        try {
            var params = new URLSearchParams();
            if (state.query) { params.set("q", state.query); }
            if (state.category !== "all") { params.set("category", state.category); }
            if (state.venue !== "all") { params.set("venue", state.venue); }
            var qs = params.toString();
            history.replaceState(null, "", window.location.pathname + (qs ? "?" + qs : ""));
        } catch (err) { /* opening from a file:// path can block this; harmless */ }
    }

    function loadFromURL() {
        var params = new URLSearchParams(window.location.search);
        state.query = (params.get("q") || "").slice(0, 60);
        if (["core", "community"].indexOf(params.get("category")) > -1) { state.category = params.get("category"); }
        if (["Kempton Park", "Hluvukani"].indexOf(params.get("venue")) > -1) { state.venue = params.get("venue"); }
        searchInput.value = state.query; venueSelect.value = state.venue;
    }

    searchInput.addEventListener("input", utils.debounce(function () { state.query = searchInput.value.trim(); render(); }, 180));
    sortSelect.addEventListener("change", function () { state.sort = sortSelect.value; render(); });
    venueSelect.addEventListener("change", function () { state.venue = venueSelect.value; render(); });
    chips.forEach(function (chip) {
        chip.addEventListener("click", function () { state.category = chip.getAttribute("data-category"); render(); });
    });
    resetBtn.addEventListener("click", resetAll);

    document.addEventListener("DOMContentLoaded", function () { loadFromURL(); render(); });
})();
