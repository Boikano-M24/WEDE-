// =====================================================================
// enquiry.js: the enquiry form (enrol / volunteer / mentor / sponsor / partner).
//
// What it does
//   1. Shows only the fields relevant to the chosen enquiry type.
//   2. Validates every visible field (formats, lengths, ranges, dates, age,
//      cross-field rules) with clear inline messages + an error summary.
//   3. On a valid submit: shows a "processing" state, sends the data with
//      AJAX (fetch) and builds a PERSONALISED RESPONSE from the answers:
//        enrol     -> programme cost (free), next start date, registration
//                     deadline, venue and what to bring
//        volunteer -> matching time slots, hours per month, next orientation
//                     day on/after the chosen start date, screening timeline
//        mentor    -> mentoring commitment, next orientation, matching process
//        sponsor   -> impact of the gift (packs / places / hub), annual total,
//                     sponsor tier, Section 18A eligibility, payment timeline
//        partner   -> meeting slots, response timeline
//   4. Lets the visitor email the compiled enquiry to the team (mailto).
//
// Everything typed by the visitor is inserted with textContent (never
// innerHTML), so it cannot inject markup into the page.
// =====================================================================
(function () {
    "use strict";

    var ATLF = window.ATLF, utils = ATLF.utils, forms = ATLF.forms, R = forms.rules;
    var $ = utils.$, $$ = utils.$$, el = utils.el;

    var form = $("#enquiry-form");
    if (!form || !window.ATLF_DATA) { return; }

    var cfg = window.ATLF_CONFIG || {};
    var costs = cfg.costs || { dignityPack: 85, academySeat: 1200, hubMonth: 3500 };
    var programmes = window.ATLF_DATA.programmes;
    var events = window.ATLF_DATA.events;
    var recipient = cfg.recipientEmail || window.ATLF_DATA.orgEmail;

    var typeSelect = $("#enquiryType");
    var statusEl = $("#enquiry-status"), submitBtn = $("#enquiry-submit"), responseBox = $("#enquiry-response");

    var TYPE_LABEL = { enrolment: "Programme enrolment", volunteer: "Volunteer", mentor: "Mentor", sponsor: "Sponsorship / donation", partner: "Partnership" };
    var AVAILABILITY = {
        weekday: { label: "Weekday afternoons", detail: "Tuesday & Thursday workshops, 15:30–17:00", hours: 12 },
        saturday: { label: "Saturday mornings", detail: "Saturday leadership circles & Academy, 09:00–13:00", hours: 16 },
        holidays: { label: "School-holiday camps", detail: "Three-day holiday camps, 09:00–15:00", hours: 6 }
    };
    var CAUSE_LABEL = { dignity: "A Thousand Ways to Smile", academy: "Entrepreneurial Academy", hub: "Hluvukani Innovation Hub", general: "Where it is needed most" };

    var today = utils.today(), todayISO = utils.toISO(today);
    var plusYear = new Date(today.getFullYear() + 1, today.getMonth(), today.getDate()), plusYearISO = utils.toISO(plusYear);
    var minDob = utils.toISO(new Date(today.getFullYear() - 30, 0, 1));

    // Date pickers only offer sensible dates
    $("#dob").setAttribute("max", todayISO);
    $("#dob").setAttribute("min", minDob);
    $("#startDate").setAttribute("min", todayISO);
    $("#startDate").setAttribute("max", plusYearISO);

    function money(n) { return "R" + Math.round(n).toLocaleString("en-GB"); }
    function programmeById(id) { return programmes.filter(function (p) { return p.id === id; })[0]; }
    function nextIntake(p) {
        var future = (p.intakes || []).filter(function (d) { return d >= todayISO; }).sort();
        return future.length ? utils.parseISO(future[0]) : null;
    }

    // ------------------------------------------------------------------
    // VALIDATION RULES (re-evaluated whenever values change)
    // ------------------------------------------------------------------
    function dobAge(v) {
        if (!v.dob || isNaN(utils.parseISO(v.dob).getTime())) { return null; }
        return forms.ageOn(v.dob, today);
    }

    function getRules(v) {
        var rules = {
            fullName: [R.required("Please enter your full name."), R.minLength(2, "Your name must be at least 2 characters."),
                       R.maxLength(60, "Your name must be 60 characters or fewer."),
                       R.pattern(/^[\p{L}][\p{L}\s'’.\-]*$/u, "Use letters, spaces, hyphens and apostrophes only.")],
            email: [R.required("Please enter your email address."), R.email("Enter a valid email address, for example name@example.com.")],
            phone: [R.saPhone("Enter a valid South African number, for example 082 123 4567.")],
            enquiryType: [R.required("Please choose what you would like to do.")],
            message: [R.maxLength(600, "Please keep your message to 600 characters or fewer.")],
            consent: [R.required("Please tick the box to agree before submitting.")]
        };

        switch (v.enquiryType) {
            case "enrolment":
                rules.teenName = [R.required("Please enter the teenager's full name."), R.minLength(2, "The name must be at least 2 characters."),
                                  R.maxLength(60, "The name must be 60 characters or fewer."),
                                  R.pattern(/^[\p{L}][\p{L}\s'’.\-]*$/u, "Use letters, spaces, hyphens and apostrophes only.")];
                rules.dob = [R.required("Please enter the teenager's date of birth."), R.validDate("That date is not valid."),
                             R.dateRange(minDob, todayISO, "The date of birth cannot be in the future."),
                             R.custom(function (val, all) {
                                 var age = dobAge(all);
                                 if (age === null) { return ""; }
                                 if (age < 13) { return "Our programmes are for ages 13 to 19; this teenager is " + age + ". Please contact us about future options."; }
                                 if (age > 19) { return "Our programmes are for ages 13 to 19. For adults, please choose Volunteer or Mentor instead."; }
                                 return "";
                             })];
                rules.programme = [R.required("Please choose a programme.")];
                rules.venue = [R.required("Please choose a venue."),
                               R.custom(function (val, all) {
                                   var p = programmeById(all.programme);
                                   if (!val || !p || p.venues.indexOf(val) > -1) { return ""; }
                                   return p.title + " runs at " + p.venues.join(" and ") + " only. Please choose that venue.";
                               })];
                rules.guardianName = [R.required("A parent or guardian's name is required for teenagers under 18."),
                                      R.maxLength(60, "The name must be 60 characters or fewer.")];
                rules.guardianConsent = [R.required("A parent or guardian must give consent for teenagers under 18.")];
                break;

            case "volunteer":
            case "mentor":
                rules.availability = [R.required("Choose at least one time when you can help.")];
                rules.startDate = [R.required("Choose the earliest date you can start."), R.validDate("That date is not valid."),
                                   R.dateRange(todayISO, plusYearISO, "Choose a start date between today and " + utils.formatDate(plusYear, "short") + ".")];
                rules.skills = [R.maxLength(300, "Please keep this to 300 characters or fewer.")];
                rules.over18 = [R.required("Volunteers and mentors must be 18 or older and agree to a background check.")];
                break;

            case "sponsor":
                rules.amount = [R.required("Enter the amount you would like to give."),
                                R.numberRange(50, 1000000, "Enter a whole-rand amount between R50 and R1,000,000.")];
                rules.frequency = [R.required("Choose once-off or monthly.")];
                rules.cause = [R.required("Choose where your gift should go.")];
                break;

            case "partner":
                rules.organisation = [R.required("Please enter your organisation's name."), R.minLength(2, "The name must be at least 2 characters."),
                                      R.maxLength(80, "The name must be 80 characters or fewer.")];
                rules.partnershipType = [R.required("Choose the type of partnership.")];
                break;
        }
        return rules;
    }

    var validator = new forms.Validator(form, getRules, { summary: $("#enquiry-summary") });
    forms.counter(form);

    // ------------------------------------------------------------------
    // ADAPTIVE SECTIONS
    // ------------------------------------------------------------------
    function syncType() {
        var type = typeSelect.value;
        $$(".conditional", form).forEach(function (sec) {
            var types = sec.getAttribute("data-for").split(" ");
            sec.hidden = types.indexOf(type) === -1;
        });
        syncGuardian();
    }

    // Guardian fields appear only when the date of birth shows the teenager is under 18
    function syncGuardian() {
        var age = dobAge(validator.values());
        var minor = age !== null && age < 18;
        ["guardianName", "guardianConsent"].forEach(function (name) {
            var wrap = validator.wrapperOf(name);
            if (wrap) { wrap.hidden = !minor; if (!minor) { validator.setError(name, ""); } }
        });
    }

    typeSelect.addEventListener("change", syncType);
    form.addEventListener("input", function (e) {
        if (e.target.name === "dob") { syncGuardian(); }
    });
    form.addEventListener("change", function (e) {
        if (e.target.name === "dob") { syncGuardian(); }
        // Cross-field rules: keep dependent messages fresh
        if (e.target.name === "programme" && validator.touched.venue) { validator.validateField("venue"); }
        if (e.target.name === "dob" && validator.touched.programme) { validator.validateField("programme"); }
    });

    // Deep links from other pages: enquiry.html?type=sponsor&cause=dignity&programme=...
    function applyURLParams() {
        var params = new URLSearchParams(window.location.search);
        var type = params.get("type");
        if (type && TYPE_LABEL[type]) { typeSelect.value = type; }
        syncType();
        var prog = params.get("programme");
        if (prog && programmeById(prog)) { $("#programme").value = prog; }
        var cause = params.get("cause");
        if (cause && CAUSE_LABEL[cause]) { $("#cause").value = cause; }
    }

    // ------------------------------------------------------------------
    // PERSONALISED RESPONSE BUILDERS
    //   each returns { intro, rows: [[label, value]], blocks: [{title, lines: []}] }
    // ------------------------------------------------------------------
    function nextOrientation(afterDate) {
        var after = utils.toISO(afterDate);
        return events.filter(function (e) { return e.category === "orientation" && e.date >= after; })
                     .sort(function (a, b) { return a.date.localeCompare(b.date); })[0] || null;
    }

    function buildEnrolment(v) {
        var p = programmeById(v.programme), age = dobAge(v), ni = nextIntake(p);
        var followUp = utils.addWorkingDays(today, 5);
        var lines = [
            "Programme fee: " + (p.cost.indexOf("Free") === 0 ? "free. There is no registration fee and no cost to take part." : p.cost + "."),
            "Duration: " + p.duration + ", " + p.schedule + "."
        ];
        var availability = ni ? [
            "Next start date: " + utils.formatDate(ni) + ".",
            "Venue: " + v.venue + ". Places are limited to 25 per venue per intake.",
            "Register by " + utils.formatDate(new Date(ni.getTime() - 7 * 86400000), "short") + " to guarantee your place."
        ] : ["The next intake date will be confirmed. We will contact you with dates for " + p.title + "."];
        var next = ["We will confirm " + v.teenName + "'s place by " + utils.formatDate(followUp, "short") + ".",
                    "Bring a copy of an ID or birth certificate and a notebook to the first session."];
        if (age !== null && age < 18) { next.push("Because " + v.teenName + " is under 18, " + v.guardianName + " must sign the consent form at the first session."); }
        return {
            intro: "Great news: " + v.teenName + " is eligible for " + p.title + ".",
            rows: [["Teenager", v.teenName + " (age " + age + ")"], ["Programme", p.title], ["Venue", v.venue]],
            blocks: [{ title: "Cost", lines: lines }, { title: "Availability", lines: availability }, { title: "Next steps", lines: next }]
        };
    }

    function buildVolunteer(v, isMentor) {
        var start = utils.parseISO(v.startDate);
        var selected = v.availability.map(function (k) { return AVAILABILITY[k]; });
        var hours = isMentor ? 6 : selected.reduce(function (sum, a) { return sum + a.hours; }, 0);
        var orientation = nextOrientation(start > today ? start : today);
        var screening = utils.addWorkingDays(orientation ? utils.parseISO(orientation.date) : today, 5);

        var fit = isMentor
            ? ["Mentoring commitment: two one-hour sessions a month for six months, plus a monthly mentor check-in (about " + hours + " hours a month in total).",
               "Your availability (" + selected.map(function (a) { return a.label.toLowerCase(); }).join(", ") + ") helps us match you with a mentee whose schedule fits."]
            : selected.map(function (a) { return a.label + ": " + a.detail + "."; })
                      .concat(["Estimated time: about " + hours + " hours a month if you cover all the slots you chose."]);

        var orient = orientation
            ? ["Your first step is our Volunteer & Mentor Orientation Day:",
               utils.formatDate(utils.parseISO(orientation.date)) + ", " + orientation.start + "–" + orientation.end + " at " + orientation.venue + "."]
            : ["We will confirm the date of the next orientation day by email."];

        return {
            intro: "Here is how your offer to " + (isMentor ? "mentor" : "volunteer") + " fits with our programmes.",
            rows: [["Role", isMentor ? "Mentor" : "Volunteer"], ["Available", selected.map(function (a) { return a.label; }).join(", ")], ["Earliest start", utils.formatDate(start, "short")]],
            blocks: [
                { title: "Cost", lines: ["Free. We cover safeguarding training, materials and background-check fees."] },
                { title: isMentor ? "Your mentoring commitment" : "Where you can help", lines: fit },
                { title: "Availability: orientation", lines: orient },
                { title: "Screening", lines: ["References and background checks are completed within five working days of orientation (by " + utils.formatDate(screening, "short") + " if you attend the date above)."] }
            ]
        };
    }

    function buildSponsor(v) {
        var amount = Number(v.amount), monthly = v.frequency === "monthly";
        var annual = monthly ? amount * 12 : amount;
        var impact = [], per = monthly ? " every month" : "";

        if (v.cause === "dignity") {
            impact.push("Your " + money(amount) + per + " provides " + Math.floor(amount / costs.dignityPack) + " dignity pack(s) at " + money(costs.dignityPack) + " each" + (monthly ? " (" + Math.floor(annual / costs.dignityPack) + " over a year)." : "."));
        } else if (v.cause === "academy") {
            var seats = annual / costs.academySeat;
            impact.push(seats >= 1 ? "Over " + (monthly ? "a year" : "this gift") + ", " + money(annual) + " fully funds " + Math.floor(seats) + " Entrepreneurial Academy place(s) at " + money(costs.academySeat) + " each."
                                   : "Your " + money(annual) + " covers about " + Math.max(1, Math.round(seats * 100)) + "% of one teen's Entrepreneurial Academy place (" + money(costs.academySeat) + ").");
        } else if (v.cause === "hub") {
            var pct = Math.round((amount / costs.hubMonth) * 100);
            impact.push("Your " + money(amount) + per + " covers about " + Math.min(pct, 100) + "% of the Innovation Hub's monthly running costs (" + money(costs.hubMonth) + ": internet, electricity and facilitators).");
        } else {
            var third = annual / 3;
            impact.push("Your gift is shared across our three priorities: about " + Math.floor(third / costs.dignityPack) + " dignity packs, " + Math.round((third / costs.academySeat) * 100) + "% of an Academy place and " + Math.round((third / (costs.hubMonth * 12)) * 100) + "% of a year at the Innovation Hub.");
        }

        var tier = annual >= 10000 ? "Founding Partner" : annual >= 3000 ? "Leader" : annual >= 500 ? "Champion" : "Friend of Akhona Teens";
        var tax = annual >= 500
            ? "Your " + (monthly ? "annual total of " : "gift of ") + money(annual) + " qualifies for a Section 18A tax certificate. Reply to our confirmation email to request it."
            : "Donations of R500 or more in a year qualify for a Section 18A tax certificate. Your " + (monthly ? "annual total is " : "gift is ") + money(annual) + ".";

        return {
            intro: "Your generosity changes lives. Here is what your gift will do.",
            rows: [["Gift", money(amount) + (monthly ? " per month" : " once-off")], ["Goes to", CAUSE_LABEL[v.cause]], ["Annual total", money(annual)], ["Sponsor level", tier]],
            blocks: [
                { title: "Your impact", lines: impact },
                { title: "Tax certificate", lines: [tax] },
                { title: "Payment", lines: ["We will email EFT and card payment options by " + utils.formatDate(utils.addWorkingDays(today, 2), "short") + ". Nothing is charged through this website."] }
            ]
        };
    }

    function buildPartner(v) {
        var first = utils.addWorkingDays(today, 3), slots = [];
        for (var i = 0; i < 3; i++) { slots.push(utils.addWorkingDays(first, i)); }
        return {
            intro: "We would love to explore a partnership with " + v.organisation + ".",
            rows: [["Organisation", v.organisation], ["Partnership type", $("#partnershipType").selectedOptions[0].textContent]],
            blocks: [
                { title: "Cost", lines: ["There is no cost to explore a partnership. We will share a partnership overview with options for every budget."] },
                { title: "Availability: first call", lines: ["We can meet by phone or video at 10:00 on any of these days:"].concat(slots.map(function (d) { return utils.formatDate(d); })) },
                { title: "Next steps", lines: ["Our programmes team will email you by " + utils.formatDate(first, "short") + " to confirm a time and send the overview pack."] }
            ]
        };
    }

    function buildResponse(v) {
        switch (v.enquiryType) {
            case "enrolment": return buildEnrolment(v);
            case "volunteer": return buildVolunteer(v, false);
            case "mentor": return buildVolunteer(v, true);
            case "sponsor": return buildSponsor(v);
            default: return buildPartner(v);
        }
    }

    // ------------------------------------------------------------------
    // COMPILED EMAIL (so the visitor can send the enquiry from their own email app)
    // ------------------------------------------------------------------
    function compileEmail(v, ref, result) {
        var lines = ["Hello Akhona Teens team,", "", "I submitted the following enquiry on your website (reference " + ref + ").", "",
                     "Enquiry type: " + TYPE_LABEL[v.enquiryType], "Name: " + v.fullName, "Email: " + v.email, "Phone: " + (v.phone || "not provided")];
        result.rows.forEach(function (r) { lines.push(r[0] + ": " + r[1]); });
        if (v.message) { lines.push("", "Message:", v.message); }
        lines.push("", "Kind regards,", v.fullName);
        return { to: recipient, subject: "[Website enquiry] " + TYPE_LABEL[v.enquiryType] + " – " + v.fullName + " (" + ref + ")", body: lines.join("\n") };
    }

    // ------------------------------------------------------------------
    // RENDER THE RESPONSE
    // ------------------------------------------------------------------
    function renderResponse(v, ref, result, ajax) {
        var mail = compileEmail(v, ref, result);
        responseBox.textContent = "";

        responseBox.appendChild(el("span", { class: "response-ref", text: "Reference: " + ref }));
        responseBox.appendChild(el("h2", { text: "Thank you, " + v.fullName.split(/\s+/)[0] + "!" }));
        responseBox.appendChild(el("p", { class: "lede", text: result.intro }));

        var facts = el("dl", { class: "facts" });
        result.rows.forEach(function (r) { facts.appendChild(el("dt", { text: r[0] })); facts.appendChild(el("dd", { text: r[1] })); });
        responseBox.appendChild(facts);

        result.blocks.forEach(function (b) {
            var block = el("div", { class: "response-block" }, [el("h3", { text: b.title })]);
            if (b.lines.length > 2 && /Availability: first call/.test(b.title)) {
                block.appendChild(el("p", { text: b.lines[0] }));
                block.appendChild(el("ul", { class: "bullets" }, b.lines.slice(1).map(function (l) { return el("li", { text: l }); })));
            } else {
                b.lines.forEach(function (l) { block.appendChild(el("p", { text: l })); });
            }
            responseBox.appendChild(block);
        });

        // Delivery note (AJAX result)
        var note = ajax.ok
            ? "Your enquiry was submitted successfully" + (ajax.data && ajax.data.id ? " (confirmation #" + ajax.data.id + ")" : "") + ". A team member will follow up within five working days."
            : ajax.reason === "disabled"
                ? "A team member will follow up within five working days. You can also email the enquiry below."
                : "We could not reach the server just now (" + ajax.reason + "), so please use the button below to email your enquiry to us directly.";
        responseBox.appendChild(el("p", { class: ajax.ok ? "form-status is-ok" : "form-status is-error", role: "status", text: note }));

        var emailBtn = el("a", { class: "btn btn--primary", href: forms.mailto(mail.to, mail.subject, mail.body), text: "Email this enquiry to " + mail.to });
        var copyBtn = el("button", { class: "btn btn--outline", type: "button", text: "Copy enquiry summary" });
        var againBtn = el("button", { class: "btn btn--outline", type: "button", text: "Make another enquiry" });
        copyBtn.addEventListener("click", function () {
            forms.copyText(mail.subject + "\n\n" + mail.body).then(function () { copyBtn.textContent = "Copied ✓"; }, function () { copyBtn.textContent = "Copy failed. Select and copy manually"; });
        });
        againBtn.addEventListener("click", function () {
            responseBox.hidden = true; form.hidden = false;
            validator.reset(); syncType();
            typeSelect.focus();
            window.scrollTo({ top: form.getBoundingClientRect().top + window.scrollY - 90, behavior: "smooth" });
        });
        responseBox.appendChild(el("div", { class: "cta-row" }, [emailBtn, copyBtn, againBtn]));

        form.hidden = true;
        responseBox.hidden = false;
        responseBox.focus();
        responseBox.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
    }

    // ------------------------------------------------------------------
    // SUBMIT
    // ------------------------------------------------------------------
    var busy = false;
    function setStatus(text, kind, spinner) {
        statusEl.textContent = "";
        statusEl.className = "form-status" + (kind ? " is-" + kind : "");
        if (spinner) { statusEl.appendChild(el("span", { class: "spinner", "aria-hidden": "true" })); }
        statusEl.appendChild(document.createTextNode(text));
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        if (busy) { return; }

        var errors = validator.validateAll();
        if (errors.length) {
            setStatus("Please correct the highlighted fields and try again.", "error");
            return;
        }

        // Honeypot: bots fill the hidden field. Pretend success, send nothing.
        if (form.elements.website && form.elements.website.value) { setStatus("Thank you!", "ok"); return; }

        busy = true;
        submitBtn.disabled = true;
        setStatus("Processing your enquiry…", "", true);

        var values = validator.values();
        var ref = forms.reference();
        var result = buildResponse(values);
        var payload = Object.assign({ reference: ref, submittedAt: new Date().toISOString(), page: "enquiry" }, values);

        // AJAX request + a short minimum delay so the "processing" state is readable
        Promise.all([forms.sendAjax(payload), new Promise(function (r) { setTimeout(r, 600); })]).then(function (out) {
            renderResponse(values, ref, result, out[0]);
            setStatus("", "");
            busy = false;
            submitBtn.disabled = false;
        });
    });

    // Initial state
    document.addEventListener("DOMContentLoaded", function () { applyURLParams(); });
})();
