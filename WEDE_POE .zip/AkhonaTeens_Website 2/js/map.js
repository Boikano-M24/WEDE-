// =====================================================================
// map.js: interactive location map (Leaflet + OpenStreetMap).
//
//   * Two markers (Kempton Park head office, Hluvukani Innovation Hub),
//     each with a popup: address, opening hours, phone and directions.
//   * Location cards beside the map fly the map to that location.
//   * "Show both locations" fits the whole of South Africa's two sites.
//   * "Find my nearest" uses the browser's geolocation (only when the
//     visitor clicks it) and works out the distance with the haversine formula.
//   * A layers control toggles shaded "service area" circles.
//   * Scroll-wheel zoom switches on only after the map is clicked, so the
//     map never traps page scrolling.
//
// Leaflet is loaded from js/vendor/leaflet.js (kept locally, no CDN needed).
// Map tiles © OpenStreetMap contributors.
// =====================================================================
(function () {
    "use strict";

    var utils = window.ATLF.utils, el = utils.el, $ = utils.$, $$ = utils.$$;
    var mapEl = $("#map");
    if (!mapEl || !window.ATLF_DATA) { return; }

    var statusEl = $("#map-status");
    var locations = window.ATLF_DATA.locations;
    var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // If Leaflet failed to load, leave the static list of addresses in place.
    if (typeof window.L === "undefined") {
        statusEl.textContent = "The interactive map could not be loaded. Use the directions links to find each location.";
        return;
    }
    var L = window.L;

    mapEl.textContent = "";                                  // remove the no-JavaScript fallback list
    var map = L.map(mapEl, { scrollWheelZoom: false, zoomControl: true, worldCopyJump: false });

    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
    }).addTo(map);
    L.control.scale({ imperial: false }).addTo(map);

    // ------------------------------------------------------------------
    // Markers + popups
    // ------------------------------------------------------------------
    var markers = {}, areas = L.layerGroup();

    function popupContent(loc) {
        var dir = "https://www.google.com/maps/dir/?api=1&destination=" + loc.lat + "," + loc.lng;
        return el("div", {}, [
            el("h3", { text: loc.name }),
            el("p", { text: loc.address }),
            el("p", { text: loc.hours }),
            el("p", {}, [
                el("a", { href: "tel:+27119724456", text: loc.phone }), " · ",
                el("a", { href: dir, target: "_blank", rel: "noopener noreferrer", text: "Get directions" })
            ])
        ]);
    }

    locations.forEach(function (loc, i) {
        var icon = L.divIcon({
            className: "",
            html: '<div class="atlf-pin' + (i === 1 ? " atlf-pin--teal" : "") + '"><span>' + loc.num + "</span></div>",
            iconSize: [34, 34], iconAnchor: [17, 34], popupAnchor: [0, -32]
        });
        var marker = L.marker([loc.lat, loc.lng], { icon: icon, title: loc.name, alt: loc.name, keyboard: true })
            .bindPopup(popupContent(loc), { maxWidth: 280, autoPanPaddingTopLeft: [30, 60], autoPanPaddingBottomRight: [30, 30] })
            .addTo(map);
        marker.on("click", function () { setActive(loc.id); });
        markers[loc.id] = marker;

        L.circle([loc.lat, loc.lng], {
            radius: loc.radiusKm * 1000, color: i === 1 ? "#157A6E" : "#4A2E83", weight: 2, fillOpacity: 0.1
        }).bindTooltip(loc.name + ": area we serve (about " + loc.radiusKm + " km)").addTo(areas);
    });

    areas.addTo(map);
    L.control.layers(null, { "Areas we serve": areas }, { collapsed: false, position: "topright" }).addTo(map);

    // ------------------------------------------------------------------
    // View helpers
    // ------------------------------------------------------------------
    function fitAll() {
        var bounds = L.latLngBounds(locations.map(function (l) { return [l.lat, l.lng]; }));
        map.fitBounds(bounds, { padding: [60, 60], animate: !reduceMotion });
    }

    function setActive(id) {
        $$("[data-location]").forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-location") === id)); });
    }

    function pulse(marker) {
        var pin = marker.getElement() && marker.getElement().querySelector(".atlf-pin");
        if (!pin) { return; }
        pin.classList.add("is-active");
        setTimeout(function () { pin.classList.remove("is-active"); }, 3000);
    }

    function flyTo(id) {
        var loc = locations.filter(function (l) { return l.id === id; })[0];
        if (!loc) { return; }
        setActive(id);
        if (reduceMotion) { map.setView([loc.lat, loc.lng], 14); }
        else { map.flyTo([loc.lat, loc.lng], 14, { duration: 1.4 }); }
        markers[id].openPopup();
        pulse(markers[id]);
        statusEl.textContent = "Showing " + loc.name + ".";
    }

    // ------------------------------------------------------------------
    // Nearest location (haversine distance, in km)
    // ------------------------------------------------------------------
    function distanceKm(lat1, lng1, lat2, lng2) {
        var R = 6371, rad = Math.PI / 180;
        var dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    var youMarker = null;
    function findNearest() {
        if (!navigator.geolocation) {
            statusEl.textContent = "Your browser does not support location finding. Choose a location from the list instead.";
            return;
        }
        statusEl.textContent = "Finding your location… please allow location access if asked.";
        navigator.geolocation.getCurrentPosition(function (pos) {
            var lat = pos.coords.latitude, lng = pos.coords.longitude;
            var ranked = locations.map(function (l) {
                return { loc: l, km: distanceKm(lat, lng, l.lat, l.lng) };
            }).sort(function (a, b) { return a.km - b.km; });
            var best = ranked[0];

            if (youMarker) { map.removeLayer(youMarker); }
            youMarker = L.circleMarker([lat, lng], { radius: 9, color: "#fff", weight: 3, fillColor: "#F2A93B", fillOpacity: 1 })
                .bindTooltip("You are here").addTo(map);

            map.fitBounds([[lat, lng], [best.loc.lat, best.loc.lng]], { padding: [70, 70], maxZoom: 12, animate: !reduceMotion });
            setActive(best.loc.id);
            markers[best.loc.id].openPopup();
            pulse(markers[best.loc.id]);
            statusEl.textContent = "Your nearest location is " + best.loc.name + ", about " + Math.round(best.km).toLocaleString("en-GB") + " km away.";
        }, function (err) {
            var msg = err.code === 1 ? "Location access was blocked. You can still choose a location from the list."
                    : err.code === 3 ? "Finding your location took too long. Please try again."
                    : "We could not work out your location. Choose a location from the list instead.";
            statusEl.textContent = msg;
        }, { timeout: 10000, maximumAge: 600000 });
    }

    // ------------------------------------------------------------------
    // Wire up the controls
    // ------------------------------------------------------------------
    $$("[data-location]").forEach(function (btn) {
        btn.addEventListener("click", function () { flyTo(btn.getAttribute("data-location")); });
    });
    var allBtn = $("#map-all"), nearBtn = $("#map-nearest");
    if (allBtn) { allBtn.addEventListener("click", function () { fitAll(); setActive(""); statusEl.textContent = "Showing both locations."; }); }
    if (nearBtn) { nearBtn.addEventListener("click", findNearest); }

    // Scroll-wheel zoom only after the visitor interacts with the map
    map.on("focus click", function () { map.scrollWheelZoom.enable(); });
    map.on("blur", function () { map.scrollWheelZoom.disable(); });

    setActive("");
    fitAll();
    // Make the map available to automated tests / debugging
    window.ATLF.map = map;
})();
