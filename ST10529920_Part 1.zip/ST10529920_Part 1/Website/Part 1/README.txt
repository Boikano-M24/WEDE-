

AKHONA TEENS LEADERSHIP FOUNDATION 

HTML file.

Pages:
- index.html
- about.html
- programmes.html
- get-involved.html
- news.html
- contact.html
- donate.html

The pages intentionally avoid unverified impact statistics, payment details and contact information.
CSS, JavaScript and PHP can be added in the next development phase.


